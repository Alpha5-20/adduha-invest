import test from 'node:test';
import assert from 'node:assert/strict';
import { computeScreening } from '../src/screening.js';
import { addBusinessDays, parseCsv, toInt } from '../src/util.js';

const settings = { debt_threshold: 0.3, deposit_threshold: 0.3, impure_threshold: 0.05 };
const sec = { activity: 'LICITE', shares_outstanding: 1_000_000 };
const fin = (o = {}) => ({ fiscal_year: 2025, interest_debt: 100_000_000, interest_deposits: 50_000_000, total_revenue: 1_000_000_000, impure_income: 10_000_000, ...o });

test('titre conforme : trois ratios sous les seuils', () => {
  const r = computeScreening(sec, fin(), 1000, settings, 2026); // capitalisation 1 Md
  assert.equal(r.status, 'CONFORME');
  assert.equal(r.debt_ratio, 0.1);
  assert.equal(r.impure_ratio, 0.01);
});
test('endettement au-dessus de 30 % : non conforme', () => {
  assert.equal(computeScreening(sec, fin({ interest_debt: 310_000_000 }), 1000, settings, 2026).status, 'NON_CONFORME');
});
test('exactement au seuil : conforme', () => {
  assert.equal(computeScreening(sec, fin({ interest_debt: 300_000_000 }), 1000, settings, 2026).status, 'CONFORME');
});
test('revenus illicites au-dessus de 5 % : non conforme', () => {
  assert.equal(computeScreening(sec, fin({ impure_income: 60_000_000 }), 1000, settings, 2026).status, 'NON_CONFORME');
});
test('activité exclue : non conforme quels que soient les ratios', () => {
  assert.equal(computeScreening({ ...sec, activity: 'EXCLUE', activity_note: 'Tabac' }, fin(), 1000, settings, 2026).status, 'NON_CONFORME');
});
test('activité non classée, données manquantes ou anciennes : à revoir', () => {
  assert.equal(computeScreening({ ...sec, activity: 'A_CLASSER' }, fin(), 1000, settings, 2026).status, 'A_REVOIR');
  assert.equal(computeScreening(sec, null, 1000, settings, 2026).status, 'A_REVOIR');
  assert.equal(computeScreening(sec, fin(), null, settings, 2026).status, 'A_REVOIR');
  assert.equal(computeScreening(sec, fin({ fiscal_year: 2023 }), 1000, settings, 2026).status, 'A_REVOIR');
});
test('T+2 saute le week-end', () => {
  assert.equal(addBusinessDays('2026-11-12', 2), '2026-11-16'); // jeudi -> lundi
  assert.equal(addBusinessDays('2026-11-10', 2), '2026-11-12');
});
test('lecture CSV avec point-virgule et espaces dans les nombres', () => {
  const rows = parseCsv('ticker;date;close\nSNTS;2026-11-10;25 000\n');
  assert.equal(rows[0].ticker, 'SNTS');
  assert.equal(toInt(rows[0].close), 25000);
  assert.equal(toInt('-5'), null);
});
