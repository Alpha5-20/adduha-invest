// Configuration lue dans les variables d'environnement.
const env = process.env;

export const config = {
  appName: env.APP_NAME || 'Ad-Duha Invest',
  port: parseInt(env.PORT || '4000', 10),
  databaseUrl: env.DATABASE_URL || 'postgres://adduha:adduha@localhost:5432/adduha',
  jwtSecret: env.JWT_SECRET || '',
  jwtTtl: env.JWT_TTL || '12h',
  adminEmail: env.ADMIN_EMAIL || '',
  adminPassword: env.ADMIN_PASSWORD || '',
  production: env.NODE_ENV === 'production',
};

if (!config.jwtSecret || config.jwtSecret.length < 32) {
  if (config.production) {
    console.error('JWT_SECRET manquant ou trop court (32 caractères minimum).');
    process.exit(1);
  }
  config.jwtSecret = 'dev-secret-a-ne-jamais-utiliser-en-production-0123456789';
}

// Valeurs par défaut des paramètres modifiables dans l'administration.
export const DEFAULT_SETTINGS = {
  debt_threshold: '0.30',      // dettes portant intérêt / capitalisation
  deposit_threshold: '0.30',   // placements portant intérêt / capitalisation
  impure_threshold: '0.05',    // revenus illicites / chiffre d'affaires
  fee_rate: '0.01',            // frais par exécution, à aligner sur la grille de la SGI
  max_variation: '0.075',      // variation maximale par séance, à confirmer avec la SGI
  nisab_fcfa: '0',             // nissab de la zakat en FCFA, à saisir par l'administrateur
  zakat_rate: '0.025',
};
