CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'CLIENT' CHECK (role IN ('CLIENT','ADMIN','SGI','CHARIA')),
  full_name     TEXT,
  phone         TEXT,
  country       TEXT,
  id_type       TEXT,
  id_number     TEXT,
  sgi_account   TEXT,
  kyc_status    TEXT NOT NULL DEFAULT 'NON_SOUMIS' CHECK (kyc_status IN ('NON_SOUMIS','EN_ATTENTE','VALIDE','REJETE')),
  kyc_reason    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS securities (
  id                 SERIAL PRIMARY KEY,
  ticker             TEXT NOT NULL UNIQUE,
  name               TEXT NOT NULL,
  sector             TEXT,
  country            TEXT,
  shares_outstanding BIGINT,
  activity           TEXT NOT NULL DEFAULT 'A_CLASSER' CHECK (activity IN ('LICITE','EXCLUE','A_CLASSER')),
  activity_note      TEXT,
  active             BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS prices (
  security_id INTEGER NOT NULL REFERENCES securities(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  close       INTEGER NOT NULL CHECK (close > 0),
  PRIMARY KEY (security_id, date)
);

CREATE TABLE IF NOT EXISTS financials (
  id                SERIAL PRIMARY KEY,
  security_id       INTEGER NOT NULL REFERENCES securities(id) ON DELETE CASCADE,
  fiscal_year       INTEGER NOT NULL,
  interest_debt     BIGINT NOT NULL CHECK (interest_debt >= 0),
  interest_deposits BIGINT NOT NULL CHECK (interest_deposits >= 0),
  total_revenue     BIGINT NOT NULL CHECK (total_revenue >= 0),
  impure_income     BIGINT NOT NULL CHECK (impure_income >= 0),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (security_id, fiscal_year)
);

CREATE TABLE IF NOT EXISTS screenings (
  id            SERIAL PRIMARY KEY,
  security_id   INTEGER NOT NULL REFERENCES securities(id) ON DELETE CASCADE,
  status        TEXT NOT NULL CHECK (status IN ('CONFORME','NON_CONFORME','A_REVOIR')),
  reason        TEXT NOT NULL,
  debt_ratio    NUMERIC,
  deposit_ratio NUMERIC,
  impure_ratio  NUMERIC,
  market_cap    BIGINT,
  fiscal_year   INTEGER,
  manual        BOOLEAN NOT NULL DEFAULT FALSE,
  reviewed_by   INTEGER REFERENCES users(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS screenings_sec_idx ON screenings (security_id, id DESC);

CREATE OR REPLACE VIEW current_screening AS
  SELECT DISTINCT ON (security_id) * FROM screenings ORDER BY security_id, id DESC;

CREATE OR REPLACE VIEW last_price AS
  SELECT DISTINCT ON (security_id) security_id, date, close FROM prices ORDER BY security_id, date DESC;

CREATE TABLE IF NOT EXISTS orders (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id),
  security_id     INTEGER NOT NULL REFERENCES securities(id),
  side            TEXT NOT NULL CHECK (side IN ('ACHAT','VENTE')),
  type            TEXT NOT NULL CHECK (type IN ('MARCHE','LIMITE')),
  quantity        INTEGER NOT NULL CHECK (quantity > 0),
  limit_price     INTEGER CHECK (limit_price > 0),
  ref_price       INTEGER NOT NULL,   -- cours servant au blocage des espèces
  filled_quantity INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'RECU' CHECK (status IN ('RECU','TRANSMIS','PARTIEL','EXECUTE','ANNULE','REJETE','EXPIRE')),
  valid_until     DATE NOT NULL,
  reject_reason   TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS orders_user_idx ON orders (user_id, id DESC);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders (status);

CREATE TABLE IF NOT EXISTS executions (
  id              SERIAL PRIMARY KEY,
  order_id        INTEGER NOT NULL REFERENCES orders(id),
  quantity        INTEGER NOT NULL CHECK (quantity > 0),
  price           INTEGER NOT NULL CHECK (price > 0),
  fee             BIGINT NOT NULL DEFAULT 0,
  settlement_date DATE NOT NULL,
  executed_by     INTEGER REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS positions (
  user_id     INTEGER NOT NULL REFERENCES users(id),
  security_id INTEGER NOT NULL REFERENCES securities(id),
  quantity    INTEGER NOT NULL CHECK (quantity >= 0),
  avg_cost    NUMERIC(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, security_id)
);

-- Relevé des espèces : le solde est toujours la somme des montants (signés).
CREATE TABLE IF NOT EXISTS cash_movements (
  id         SERIAL PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  type       TEXT NOT NULL CHECK (type IN ('DEPOT','RETRAIT','ACHAT','VENTE','FRAIS','DIVIDENDE')),
  amount     BIGINT NOT NULL,
  label      TEXT,
  ref_order  INTEGER REFERENCES orders(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cash_user_idx ON cash_movements (user_id, id DESC);

CREATE TABLE IF NOT EXISTS dividends (
  id               SERIAL PRIMARY KEY,
  security_id      INTEGER NOT NULL REFERENCES securities(id),
  amount_per_share INTEGER NOT NULL CHECK (amount_per_share > 0),
  pay_date         DATE NOT NULL,
  impure_ratio     NUMERIC NOT NULL DEFAULT 0,
  created_by       INTEGER REFERENCES users(id),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purifications (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id),
  dividend_id     INTEGER NOT NULL REFERENCES dividends(id),
  quantity        INTEGER NOT NULL,
  dividend_amount BIGINT NOT NULL,
  amount_due      BIGINT NOT NULL,
  paid            BOOLEAN NOT NULL DEFAULT FALSE,
  paid_at         TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         BIGSERIAL PRIMARY KEY,
  user_id    INTEGER REFERENCES users(id),
  action     TEXT NOT NULL,
  detail     JSONB,
  ip         TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
