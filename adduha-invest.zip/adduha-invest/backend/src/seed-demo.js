// DONNÉES FICTIVES pour essayer l'application : cours, nombres d'actions et chiffres financiers
// inventés. À ne jamais lancer sur la base de production.
//   npm run seed:demo
import bcrypt from 'bcryptjs';
import { query, pool } from './db.js';
import { migrate, seed } from './seed.js';
import { getSettings } from './util.js';
import { rescreenAll } from './screening.js';

const year = new Date().getUTCFullYear() - 1;
// ticker, actions, cours, dettes à intérêt, placements à intérêt, chiffre d'affaires, revenus illicites
const DEMO = [
  ['SNTS', 100_000_000, 25000, 400_000_000_000, 150_000_000_000, 1_600_000_000_000, 16_000_000_000],
  ['ORAC', 150_000_000, 14000, 300_000_000_000, 100_000_000_000, 1_000_000_000_000, 8_000_000_000],
  ['ONTBF', 340_000_000, 2500, 300_000_000_000, 20_000_000_000, 170_000_000_000, 1_000_000_000],
  ['PALC', 15_000_000, 7000, 10_000_000_000, 5_000_000_000, 190_000_000_000, 500_000_000],
  ['SPHC', 25_000_000, 5000, 50_000_000_000, 4_000_000_000, 200_000_000_000, 300_000_000],
  ['CIEC', 56_000_000, 2300, 20_000_000_000, 60_000_000_000, 250_000_000_000, 15_000_000_000],
  ['NTLC', 22_000_000, 9000, 30_000_000_000, 10_000_000_000, 220_000_000_000, 400_000_000],
];

await migrate();
await seed();
for (const [ticker, shares, close, debt, dep, rev, impure] of DEMO) {
  const { rows: [s] } = await query(
    "UPDATE securities SET shares_outstanding=$1, activity='LICITE', activity_note='DÉMO' WHERE ticker=$2 RETURNING id", [shares, ticker]);
  let c = close;
  for (let i = 60; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    if (d.getUTCDay() === 0 || d.getUTCDay() === 6) continue;
    c = Math.max(5, Math.round((c * (1 + (Math.sin(i * 1.7 + close) * 0.012))) / 5) * 5);
    await query('INSERT INTO prices (security_id, date, close) VALUES ($1,$2,$3) ON CONFLICT (security_id, date) DO UPDATE SET close = EXCLUDED.close',
      [s.id, d.toISOString().slice(0, 10), c]);
  }
  await query(
    `INSERT INTO financials (security_id, fiscal_year, interest_debt, interest_deposits, total_revenue, impure_income)
     VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (security_id, fiscal_year) DO NOTHING`, [s.id, year, debt, dep, rev, impure]);
}
await rescreenAll({ query }, await getSettings({ query }));

const hash = await bcrypt.hash('demo-client-2026', 12);
const { rows: [u] } = await query(
  `INSERT INTO users (email, password_hash, full_name, phone, country, id_type, id_number, kyc_status)
   VALUES ('client@demo.local',$1,'Client Démo','+223 00 00 00 00','Mali','CNI','DEMO-0001','VALIDE')
   ON CONFLICT (email) DO UPDATE SET kyc_status='VALIDE' RETURNING id`, [hash]);
const { rows: [{ n }] } = await query('SELECT COUNT(*)::int AS n FROM cash_movements WHERE user_id = $1', [u.id]);
if (n === 0) await query("INSERT INTO cash_movements (user_id, type, amount, label) VALUES ($1,'DEPOT',2000000,'Dépôt de démonstration')", [u.id]);

console.log('Données de démonstration chargées. Client : client@demo.local / demo-client-2026');
await pool.end();
