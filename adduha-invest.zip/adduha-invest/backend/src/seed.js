import bcrypt from 'bcryptjs';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { query } from './db.js';
import { getSettings } from './util.js';
import { rescreenAll } from './screening.js';

// Titres de la BRVM chargés au premier démarrage. Liste et classement d'activité à vérifier
// contre la cote officielle et à faire valider par le comité charia : les sociétés au statut
// A_CLASSER restent « À revoir » tant que le comité ne s'est pas prononcé.
const B = ['EXCLUE', 'Banque ou établissement financier conventionnel'];
const SECURITIES = [
  ['SNTS', 'Sonatel', 'Télécommunications', 'Sénégal'],
  ['ORAC', "Orange Côte d'Ivoire", 'Télécommunications', "Côte d'Ivoire"],
  ['ONTBF', 'Onatel', 'Télécommunications', 'Burkina Faso'],
  ['PALC', "Palm Côte d'Ivoire", 'Agriculture', "Côte d'Ivoire"],
  ['SPHC', 'SAPH', 'Agriculture', "Côte d'Ivoire"],
  ['SOGC', 'SOGB', 'Agriculture', "Côte d'Ivoire"],
  ['SCRC', 'Sucrivoire', 'Agriculture', "Côte d'Ivoire"],
  ['SICC', 'Sicor', 'Agriculture', "Côte d'Ivoire"],
  ['NTLC', "Nestlé Côte d'Ivoire", 'Industrie', "Côte d'Ivoire"],
  ['UNLC', "Unilever Côte d'Ivoire", 'Industrie', "Côte d'Ivoire"],
  ['UNXC', 'Uniwax', 'Industrie', "Côte d'Ivoire"],
  ['FTSC', 'Filtisac', 'Industrie', "Côte d'Ivoire"],
  ['CABC', 'Sicable', 'Industrie', "Côte d'Ivoire"],
  ['SEMC', "Eviosys Packaging Siem", 'Industrie', "Côte d'Ivoire"],
  ['SMBC', 'SMB', 'Industrie', "Côte d'Ivoire"],
  ['SIVC', "Air Liquide Côte d'Ivoire", 'Industrie', "Côte d'Ivoire"],
  ['NEIC', 'NEI-CEDA', 'Industrie', "Côte d'Ivoire"],
  ['CIEC', 'CIE', 'Services publics', "Côte d'Ivoire"],
  ['SDCC', 'Sodeci', 'Services publics', "Côte d'Ivoire"],
  ['TTLC', "TotalEnergies Marketing Côte d'Ivoire", 'Distribution', "Côte d'Ivoire"],
  ['TTLS', 'TotalEnergies Marketing Sénégal', 'Distribution', 'Sénégal'],
  ['SHEC', "Vivo Energy Côte d'Ivoire", 'Distribution', "Côte d'Ivoire"],
  ['CFAC', "CFAO Motors Côte d'Ivoire", 'Distribution', "Côte d'Ivoire"],
  ['PRSC', "Tractafric Motors Côte d'Ivoire", 'Distribution', "Côte d'Ivoire"],
  ['BNBC', "Bernabé Côte d'Ivoire", 'Distribution', "Côte d'Ivoire"],
  ['ABJC', 'Servair Abidjan', 'Distribution', "Côte d'Ivoire"],
  ['SDSC', "Africa Global Logistics Côte d'Ivoire", 'Transport', "Côte d'Ivoire"],
  ['STAC', "Setao Côte d'Ivoire", 'Autres', "Côte d'Ivoire"],
  ['SLBC', 'Solibra', 'Industrie', "Côte d'Ivoire", 'EXCLUE', 'Brasserie (boissons alcoolisées)'],
  ['STBC', 'Sitab', 'Industrie', "Côte d'Ivoire", 'EXCLUE', 'Tabac'],
  ['LNBB', 'Loterie nationale du Bénin', 'Services', 'Bénin', 'EXCLUE', 'Jeux de hasard'],
  ['BOAB', 'Bank of Africa Bénin', 'Finance', 'Bénin', ...B],
  ['BOABF', 'Bank of Africa Burkina Faso', 'Finance', 'Burkina Faso', ...B],
  ['BOAC', "Bank of Africa Côte d'Ivoire", 'Finance', "Côte d'Ivoire", ...B],
  ['BOAM', 'Bank of Africa Mali', 'Finance', 'Mali', ...B],
  ['BOAN', 'Bank of Africa Niger', 'Finance', 'Niger', ...B],
  ['BOAS', 'Bank of Africa Sénégal', 'Finance', 'Sénégal', ...B],
  ['BICC', "BICI Côte d'Ivoire", 'Finance', "Côte d'Ivoire", ...B],
  ['BICB', 'BIIC', 'Finance', 'Bénin', ...B],
  ['CBIBF', 'Coris Bank International', 'Finance', 'Burkina Faso', ...B],
  ['ECOC', "Ecobank Côte d'Ivoire", 'Finance', "Côte d'Ivoire", ...B],
  ['ETIT', 'Ecobank Transnational Incorporated', 'Finance', 'Togo', ...B],
  ['NSBC', "NSIA Banque Côte d'Ivoire", 'Finance', "Côte d'Ivoire", ...B],
  ['ORGT', 'Oragroup', 'Finance', 'Togo', ...B],
  ['SAFC', 'Safca', 'Finance', "Côte d'Ivoire", ...B],
  ['SGBC', "Société Générale Côte d'Ivoire", 'Finance', "Côte d'Ivoire", ...B],
  ['SIBC', "Société Ivoirienne de Banque", 'Finance', "Côte d'Ivoire", ...B],
];

export async function migrate() {
  const sql = await readFile(fileURLToPath(new URL('./schema.sql', import.meta.url)), 'utf8');
  await query(sql);
}

export async function seed() {
  // Compte administrateur initial, créé une seule fois à partir des variables d'environnement.
  const admins = await query("SELECT 1 FROM users WHERE role = 'ADMIN' LIMIT 1");
  if (!admins.rowCount) {
    if (!config.adminEmail || config.adminPassword.length < 10) {
      console.warn('Aucun administrateur : renseignez ADMIN_EMAIL et ADMIN_PASSWORD (10 caractères minimum) puis redémarrez.');
    } else {
      await query(
        `INSERT INTO users (email, password_hash, role, full_name, kyc_status) VALUES ($1,$2,'ADMIN','Administrateur','VALIDE')
         ON CONFLICT (email) DO UPDATE SET role = 'ADMIN'`,
        [config.adminEmail.toLowerCase(), await bcrypt.hash(config.adminPassword, 12)]);
      console.log(`Compte administrateur créé : ${config.adminEmail}`);
    }
  }

  const { rows: [{ n }] } = await query('SELECT COUNT(*)::int AS n FROM securities');
  if (n === 0) {
    for (const [ticker, name, sector, country, activity = 'A_CLASSER', note = ''] of SECURITIES) {
      await query(
        'INSERT INTO securities (ticker, name, sector, country, activity, activity_note) VALUES ($1,$2,$3,$4,$5,$6)',
        [ticker, name, sector, country, activity, note]);
    }
    console.log(`${SECURITIES.length} titres chargés.`);
  }
  await rescreenAll({ query }, await getSettings({ query }));
}
