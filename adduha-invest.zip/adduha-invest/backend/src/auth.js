import jwt from 'jsonwebtoken';
import { config } from './config.js';
import { query } from './db.js';
import { HttpError, wrap } from './util.js';

export const signToken = (user) =>
  jwt.sign({ sub: user.id, role: user.role }, config.jwtSecret, { expiresIn: config.jwtTtl });

// Vérifie le jeton et recharge l'utilisateur : un changement de rôle s'applique tout de suite.
export const requireAuth = wrap(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new HttpError(401, 'Connexion requise.');
  let payload;
  try { payload = jwt.verify(token, config.jwtSecret); }
  catch { throw new HttpError(401, 'Session expirée. Reconnectez-vous.'); }
  const { rows: [user] } = await query('SELECT * FROM users WHERE id = $1', [payload.sub]);
  if (!user) throw new HttpError(401, 'Compte introuvable.');
  req.user = user;
  next();
});

export const requireRole = (...roles) => (req, _res, next) => {
  if (!roles.includes(req.user.role)) return next(new HttpError(403, "Vous n'avez pas le droit de faire cette action."));
  next();
};

export function publicUser(u) {
  const { password_hash, ...rest } = u;
  return rest;
}
