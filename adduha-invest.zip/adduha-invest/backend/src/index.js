import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { ZodError } from 'zod';
import { config } from './config.js';
import { query, pool } from './db.js';
import { migrate, seed } from './seed.js';
import authRoutes from './routes/auth.js';
import securitiesRoutes from './routes/securities.js';
import ordersRoutes from './routes/orders.js';
import portfolioRoutes from './routes/portfolio.js';
import adminRoutes from './routes/admin.js';

const app = express();
app.set('trust proxy', 1); // derrière Caddy
app.use(helmet());
app.use(express.json({ limit: '6mb' }));

app.use('/api', rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Trop de requêtes. Réessayez dans une minute.' } }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Trop de tentatives. Réessayez dans un quart d\'heure.' } }));

app.get('/api/health', async (_req, res, next) => { try {
  await query('SELECT 1');
  res.json({ ok: true, app: config.appName });
  } catch (e) { next(e); }
});

app.use('/api', authRoutes);
app.use('/api', securitiesRoutes);
app.use('/api', ordersRoutes);
app.use('/api', portfolioRoutes);
app.use('/api/admin', adminRoutes);

app.use('/api', (_req, res) => res.status(404).json({ error: 'Route inconnue.' }));

// Gestionnaire d'erreurs : messages lisibles pour le client, détail dans les journaux.
app.use((err, _req, res, _next) => {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: err.issues[0]?.message || 'Données invalides.', fields: err.issues.map((i) => i.path.join('.')) });
  }
  if (err.status) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Fichier trop volumineux.' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Requête illisible.' });
  console.error(err);
  res.status(500).json({ error: 'Erreur interne. Réessayez plus tard.' });
});

// Les ordres dont la validité est dépassée passent à l'état « Expiré ».
async function expireOrders() {
  try {
    await query("UPDATE orders SET status='EXPIRE', updated_at=now() WHERE status IN ('RECU','TRANSMIS','PARTIEL') AND valid_until < CURRENT_DATE");
  } catch (e) { console.error('Expiration des ordres :', e.message); }
}

async function start() {
  // La base peut mettre quelques secondes à démarrer avec Docker.
  for (let i = 1; ; i++) {
    try { await query('SELECT 1'); break; }
    catch (e) {
      if (i >= 30) throw e;
      console.log('Base de données pas encore prête, nouvel essai…');
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
  await migrate();
  await seed();
  await expireOrders();
  setInterval(expireOrders, 10 * 60_000).unref();
  const server = app.listen(config.port, () => console.log(`${config.appName} : API à l'écoute sur le port ${config.port}`));
  const stop = () => server.close(() => pool.end().then(() => process.exit(0)));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

start().catch((e) => { console.error(e); process.exit(1); });
