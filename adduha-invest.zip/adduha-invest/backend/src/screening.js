// Filtrage charia selon la norme AAOIFI n° 21 : activité, puis trois ratios.
// Les seuils viennent des paramètres ; le comité charia peut forcer un statut à la main.

const pct = (x) => (x * 100).toFixed(1).replace('.', ',') + ' %';

/**
 * Calcule le statut d'un titre. Fonction pure, testée dans test/screening.test.js.
 * @param security  { activity, activity_note, shares_outstanding }
 * @param financial { fiscal_year, interest_debt, interest_deposits, total_revenue, impure_income } ou null
 * @param lastClose dernier cours en FCFA ou null
 * @param settings  { debt_threshold, deposit_threshold, impure_threshold }
 * @param currentYear année civile en cours
 */
export function computeScreening(security, financial, lastClose, settings, currentYear) {
  const empty = { debt_ratio: null, deposit_ratio: null, impure_ratio: null, market_cap: null, fiscal_year: financial?.fiscal_year ?? null };

  if (security.activity === 'EXCLUE') {
    return { ...empty, status: 'NON_CONFORME', reason: `Activité exclue${security.activity_note ? ' : ' + security.activity_note : ''}.` };
  }
  if (security.activity !== 'LICITE') {
    return { ...empty, status: 'A_REVOIR', reason: "Activité pas encore classée par le comité charia." };
  }
  if (!financial) return { ...empty, status: 'A_REVOIR', reason: 'Données financières manquantes.' };
  if (!lastClose || !security.shares_outstanding) {
    return { ...empty, status: 'A_REVOIR', reason: "Cours ou nombre d'actions manquant : capitalisation impossible à calculer." };
  }
  if (!financial.total_revenue) return { ...empty, status: 'A_REVOIR', reason: "Chiffre d'affaires nul ou manquant." };

  const market_cap = security.shares_outstanding * lastClose;
  const debt_ratio = financial.interest_debt / market_cap;
  const deposit_ratio = financial.interest_deposits / market_cap;
  const impure_ratio = financial.impure_income / financial.total_revenue;
  const ratios = { debt_ratio, deposit_ratio, impure_ratio, market_cap, fiscal_year: financial.fiscal_year };

  // En année N, le dernier exercice publié est N-1, ou N-2 en début d'année.
  if (financial.fiscal_year < currentYear - 2) {
    return { ...ratios, status: 'A_REVOIR', reason: `Données financières trop anciennes (exercice ${financial.fiscal_year}).` };
  }

  const fails = [];
  if (debt_ratio > settings.debt_threshold) fails.push(`endettement ${pct(debt_ratio)} (seuil ${pct(settings.debt_threshold)})`);
  if (deposit_ratio > settings.deposit_threshold) fails.push(`placements à intérêt ${pct(deposit_ratio)} (seuil ${pct(settings.deposit_threshold)})`);
  if (impure_ratio > settings.impure_threshold) fails.push(`revenus illicites ${pct(impure_ratio)} (seuil ${pct(settings.impure_threshold)})`);

  if (fails.length) return { ...ratios, status: 'NON_CONFORME', reason: 'Seuil dépassé : ' + fails.join(' ; ') + '.' };
  return { ...ratios, status: 'CONFORME', reason: `Activité licite et trois ratios sous les seuils (exercice ${financial.fiscal_year}).` };
}

/**
 * Recalcule et enregistre le statut d'un titre.
 * Ne remplace pas une décision manuelle du comité, sauf si force = true.
 */
export async function rescreenSecurity(db, securityId, settings, { force = false, reviewedBy = null } = {}) {
  const { rows: [security] } = await db.query('SELECT * FROM securities WHERE id = $1', [securityId]);
  if (!security) return null;
  const { rows: [current] } = await db.query('SELECT * FROM current_screening WHERE security_id = $1', [securityId]);
  if (current?.manual && !force) return current;

  const { rows: [financial] } = await db.query(
    'SELECT * FROM financials WHERE security_id = $1 ORDER BY fiscal_year DESC LIMIT 1', [securityId]);
  const { rows: [price] } = await db.query('SELECT close FROM last_price WHERE security_id = $1', [securityId]);
  const r = computeScreening(security, financial || null, price?.close ?? null, settings, new Date().getUTCFullYear());

  // On n'ajoute une ligne à l'historique que si le statut ou le motif change.
  if (current && !current.manual && current.status === r.status && current.reason === r.reason) {
    await db.query(
      'UPDATE screenings SET debt_ratio=$1, deposit_ratio=$2, impure_ratio=$3, market_cap=$4 WHERE id=$5',
      [r.debt_ratio, r.deposit_ratio, r.impure_ratio, r.market_cap, current.id]);
    return { ...current, ...r };
  }
  const { rows: [row] } = await db.query(
    `INSERT INTO screenings (security_id, status, reason, debt_ratio, deposit_ratio, impure_ratio, market_cap, fiscal_year, manual, reviewed_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,FALSE,$9) RETURNING *`,
    [securityId, r.status, r.reason, r.debt_ratio, r.deposit_ratio, r.impure_ratio, r.market_cap, r.fiscal_year, reviewedBy]);
  return row;
}

export async function rescreenAll(db, settings) {
  const { rows } = await db.query('SELECT id FROM securities');
  for (const s of rows) await rescreenSecurity(db, s.id, settings);
}
