// Tout ce qui touche à la SGI partenaire passe par cet adaptateur.
//
// Version "manuel" : l'application ne parle à aucun système externe. L'opérateur SGI
// traite les ordres depuis l'espace d'administration (transmission, exécution, rejet)
// ou à partir de l'export CSV.
//
// Pour brancher le système de la SGI (API ou FIX), réécrire ces fonctions :
//  - submitOrder : envoyer l'ordre et renvoyer sa référence externe ;
//  - cancelOrder : demander l'annulation du reliquat ;
//  - et appeler applyExecution() (routes/admin.js) à chaque avis d'exécution reçu.
export const sgi = {
  name: 'manuel',
  async submitOrder(_order) { return { accepted: true, externalRef: null }; },
  async cancelOrder(_order) { return { accepted: true }; },
};
