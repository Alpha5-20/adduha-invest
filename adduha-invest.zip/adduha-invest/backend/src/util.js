import { DEFAULT_SETTINGS } from './config.js';

export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// Enveloppe une route async pour que les erreurs arrivent au gestionnaire d'erreurs.
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export async function getSettings(db) {
  const { rows } = await db.query('SELECT key, value FROM settings');
  const raw = { ...DEFAULT_SETTINGS };
  for (const r of rows) raw[r.key] = r.value;
  const s = {};
  for (const [k, v] of Object.entries(raw)) s[k] = Number(v);
  return s;
}

export async function audit(db, userId, action, detail = {}, ip = null) {
  await db.query('INSERT INTO audit_log (user_id, action, detail, ip) VALUES ($1,$2,$3,$4)',
    [userId, action, JSON.stringify(detail), ip]);
}

export const todayISO = () => new Date().toISOString().slice(0, 10);

// Ajoute n jours de bourse (samedi et dimanche exclus ; les jours fériés ne sont pas gérés).
export function addBusinessDays(isoDate, n) {
  const d = new Date(isoDate + 'T00:00:00Z');
  let left = n;
  while (left > 0) {
    d.setUTCDate(d.getUTCDate() + 1);
    const day = d.getUTCDay();
    if (day !== 0 && day !== 6) left -= 1;
  }
  return d.toISOString().slice(0, 10);
}

// Lecture d'un CSV simple : première ligne = en-têtes, séparateur virgule ou point-virgule.
export function parseCsv(text) {
  const lines = String(text || '').replace(/^﻿/, '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) throw new HttpError(400, 'Fichier vide ou sans ligne de données.');
  const sep = lines[0].includes(';') ? ';' : ',';
  const headers = lines[0].split(sep).map((h) => h.trim().toLowerCase());
  return lines.slice(1).map((line, i) => {
    const cells = line.split(sep).map((c) => c.trim());
    const row = { _line: i + 2 };
    headers.forEach((h, j) => { row[h] = cells[j] ?? ''; });
    return row;
  });
}

// Nombre entier positif ou nul à partir d'une cellule ("1 250 000" accepté).
export function toInt(value) {
  const cleaned = String(value).replace(/[\s  ]/g, '');
  if (!/^\d+$/.test(cleaned)) return null;
  return parseInt(cleaned, 10);
}
