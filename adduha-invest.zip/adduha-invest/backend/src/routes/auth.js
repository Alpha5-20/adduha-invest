import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, wrap, audit } from '../util.js';
import { signToken, requireAuth, publicUser } from '../auth.js';

const router = Router();

const credentials = z.object({
  email: z.string().trim().toLowerCase().email('Adresse e-mail invalide.'),
  password: z.string().min(10, 'Le mot de passe doit faire au moins 10 caractères.').max(200),
});

router.post('/auth/register', wrap(async (req, res) => {
  const body = credentials.extend({ full_name: z.string().trim().min(2, 'Nom requis.').max(120) }).parse(req.body);
  const exists = await query('SELECT 1 FROM users WHERE email = $1', [body.email]);
  if (exists.rowCount) throw new HttpError(409, 'Un compte existe déjà avec cette adresse.');
  const hash = await bcrypt.hash(body.password, 12);
  const { rows: [user] } = await query(
    'INSERT INTO users (email, password_hash, full_name) VALUES ($1,$2,$3) RETURNING *',
    [body.email, hash, body.full_name]);
  await audit({ query }, user.id, 'INSCRIPTION', {}, req.ip);
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
}));

router.post('/auth/login', wrap(async (req, res) => {
  const body = z.object({ email: z.string().trim().toLowerCase(), password: z.string() }).parse(req.body);
  const { rows: [user] } = await query('SELECT * FROM users WHERE email = $1', [body.email]);
  const ok = user && await bcrypt.compare(body.password, user.password_hash);
  if (!ok) throw new HttpError(401, 'E-mail ou mot de passe incorrect.');
  res.json({ token: signToken(user), user: publicUser(user) });
}));

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

// Mise à jour de la fiche d'identité. La soumission complète fait passer le dossier "en attente".
const profile = z.object({
  full_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(6).max(30),
  country: z.string().trim().min(2).max(60),
  id_type: z.enum(['CNI', 'PASSEPORT', 'CARTE_CONSULAIRE', 'NINA']),
  id_number: z.string().trim().min(4).max(40),
  sgi_account: z.string().trim().max(40).optional().default(''),
});

router.put('/me', requireAuth, wrap(async (req, res) => {
  if (req.user.kyc_status === 'VALIDE') {
    throw new HttpError(409, 'Votre dossier est déjà validé. Pour le modifier, contactez le support.');
  }
  const b = profile.parse(req.body);
  const { rows: [user] } = await query(
    `UPDATE users SET full_name=$1, phone=$2, country=$3, id_type=$4, id_number=$5, sgi_account=$6,
            kyc_status='EN_ATTENTE', kyc_reason=NULL WHERE id=$7 RETURNING *`,
    [b.full_name, b.phone, b.country, b.id_type, b.id_number, b.sgi_account || null, req.user.id]);
  await audit({ query }, user.id, 'DOSSIER_SOUMIS', {}, req.ip);
  res.json({ user: publicUser(user) });
}));

export default router;
