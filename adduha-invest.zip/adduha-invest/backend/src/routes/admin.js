import { Router } from 'express';
import { z } from 'zod';
import { query, tx } from '../db.js';
import { HttpError, wrap, getSettings, audit, parseCsv, toInt, todayISO, addBusinessDays } from '../util.js';
import { requireAuth, requireRole, publicUser } from '../auth.js';
import { rescreenSecurity, rescreenAll } from '../screening.js';
import { cashBalance, reservedCash } from '../portfolio.js';
import { DEFAULT_SETTINGS } from '../config.js';

const router = Router();
router.use(requireAuth, requireRole('ADMIN', 'SGI', 'CHARIA'));

const ADMIN = requireRole('ADMIN');
const BACK_OFFICE = requireRole('ADMIN', 'SGI');
const SHARIA = requireRole('ADMIN', 'CHARIA');
const idOf = (req) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) throw new HttpError(400, 'Identifiant invalide.');
  return id;
};

/* ---------- Clients ---------- */

router.get('/users', BACK_OFFICE, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT u.*, (SELECT COALESCE(SUM(amount),0)::bigint FROM cash_movements c WHERE c.user_id = u.id) AS cash
       FROM users u ORDER BY (u.kyc_status = 'EN_ATTENTE') DESC, u.id DESC LIMIT 500`);
  res.json({ users: rows.map(publicUser) });
}));

router.post('/users/:id/kyc', BACK_OFFICE, wrap(async (req, res) => {
  const b = z.object({ status: z.enum(['VALIDE', 'REJETE']), reason: z.string().trim().max(300).optional() }).parse(req.body);
  if (b.status === 'REJETE' && !b.reason) throw new HttpError(400, 'Indiquez le motif du rejet.');
  const { rows: [u] } = await query(
    "UPDATE users SET kyc_status=$1, kyc_reason=$2 WHERE id=$3 AND kyc_status <> 'NON_SOUMIS' RETURNING *",
    [b.status, b.status === 'REJETE' ? b.reason : null, idOf(req)]);
  if (!u) throw new HttpError(404, 'Client introuvable ou dossier non soumis.');
  await audit({ query }, req.user.id, 'DOSSIER_' + b.status, { user: u.id, reason: b.reason }, req.ip);
  res.json({ user: publicUser(u) });
}));

// Dépôt ou retrait constaté par la SGI sur le compte du client.
router.post('/users/:id/cash', BACK_OFFICE, wrap(async (req, res) => {
  const b = z.object({
    type: z.enum(['DEPOT', 'RETRAIT']),
    amount: z.number().int().positive().max(100_000_000_000),
    label: z.string().trim().max(120).optional(),
  }).parse(req.body);
  const userId = idOf(req);
  const balance = await tx(async (db) => {
    const { rows: [u] } = await db.query('SELECT id FROM users WHERE id = $1 FOR UPDATE', [userId]);
    if (!u) throw new HttpError(404, 'Client introuvable.');
    if (b.type === 'RETRAIT') {
      const settings = await getSettings(db);
      const available = (await cashBalance(db, userId)) - (await reservedCash(db, userId, settings.fee_rate));
      if (b.amount > available) throw new HttpError(409, `Retrait supérieur aux espèces disponibles (${available} FCFA).`);
    }
    await db.query('INSERT INTO cash_movements (user_id, type, amount, label) VALUES ($1,$2,$3,$4)',
      [userId, b.type, b.type === 'DEPOT' ? b.amount : -b.amount, b.label || (b.type === 'DEPOT' ? 'Dépôt' : 'Retrait')]);
    await audit(db, req.user.id, 'ESPECES_' + b.type, { user: userId, amount: b.amount }, req.ip);
    return cashBalance(db, userId);
  });
  res.json({ cash: balance });
}));

router.post('/users/:id/role', ADMIN, wrap(async (req, res) => {
  const b = z.object({ role: z.enum(['CLIENT', 'ADMIN', 'SGI', 'CHARIA']) }).parse(req.body);
  const id = idOf(req);
  if (id === req.user.id) throw new HttpError(409, 'Vous ne pouvez pas changer votre propre rôle.');
  const { rows: [u] } = await query('UPDATE users SET role=$1 WHERE id=$2 RETURNING *', [b.role, id]);
  if (!u) throw new HttpError(404, 'Utilisateur introuvable.');
  await audit({ query }, req.user.id, 'ROLE_MODIFIE', { user: id, role: b.role }, req.ip);
  res.json({ user: publicUser(u) });
}));

/* ---------- Titres et conformité ---------- */

const securitySchema = z.object({
  ticker: z.string().trim().toUpperCase().min(2).max(10),
  name: z.string().trim().min(2).max(120),
  sector: z.string().trim().max(60).optional().default(''),
  country: z.string().trim().max(60).optional().default(''),
  shares_outstanding: z.number().int().positive().nullable().optional(),
  activity: z.enum(['LICITE', 'EXCLUE', 'A_CLASSER']).default('A_CLASSER'),
  activity_note: z.string().trim().max(200).optional().default(''),
  active: z.boolean().optional().default(true),
});

router.get('/securities', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT s.*, lp.close AS last_close, lp.date AS price_date, cs.status AS sharia_status, cs.manual, cs.reason,
            (SELECT MAX(fiscal_year) FROM financials f WHERE f.security_id = s.id) AS last_fiscal_year
       FROM securities s
       LEFT JOIN last_price lp ON lp.security_id = s.id
       LEFT JOIN current_screening cs ON cs.security_id = s.id
      ORDER BY s.ticker`);
  res.json({ securities: rows });
}));

router.post('/securities', SHARIA, wrap(async (req, res) => {
  const b = securitySchema.parse(req.body);
  const dup = await query('SELECT 1 FROM securities WHERE ticker = $1', [b.ticker]);
  if (dup.rowCount) throw new HttpError(409, 'Ce code existe déjà.');
  const { rows: [s] } = await query(
    `INSERT INTO securities (ticker, name, sector, country, shares_outstanding, activity, activity_note, active)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [b.ticker, b.name, b.sector, b.country, b.shares_outstanding ?? null, b.activity, b.activity_note, b.active]);
  await rescreenSecurity({ query }, s.id, await getSettings({ query }));
  await audit({ query }, req.user.id, 'TITRE_CREE', { ticker: s.ticker }, req.ip);
  res.status(201).json({ security: s });
}));

router.put('/securities/:id', SHARIA, wrap(async (req, res) => {
  const b = securitySchema.omit({ ticker: true }).parse(req.body);
  const { rows: [s] } = await query(
    `UPDATE securities SET name=$1, sector=$2, country=$3, shares_outstanding=$4, activity=$5, activity_note=$6, active=$7
      WHERE id=$8 RETURNING *`,
    [b.name, b.sector, b.country, b.shares_outstanding ?? null, b.activity, b.activity_note, b.active, idOf(req)]);
  if (!s) throw new HttpError(404, 'Titre introuvable.');
  await rescreenSecurity({ query }, s.id, await getSettings({ query }), { reviewedBy: req.user.id });
  await audit({ query }, req.user.id, 'TITRE_MODIFIE', { ticker: s.ticker, activity: s.activity }, req.ip);
  res.json({ security: s });
}));

// Décision manuelle du comité charia (prime sur le calcul), ou retour au calcul automatique.
router.post('/securities/:id/screening', SHARIA, wrap(async (req, res) => {
  const b = z.discriminatedUnion('mode', [
    z.object({ mode: z.literal('MANUEL'), status: z.enum(['CONFORME', 'NON_CONFORME', 'A_REVOIR']), reason: z.string().trim().min(5, 'Motif requis.').max(400) }),
    z.object({ mode: z.literal('AUTO') }),
  ]).parse(req.body);
  const id = idOf(req);
  const settings = await getSettings({ query });
  let screening;
  if (b.mode === 'AUTO') {
    screening = await rescreenSecurity({ query }, id, settings, { force: true, reviewedBy: req.user.id });
    if (!screening) throw new HttpError(404, 'Titre introuvable.');
  } else {
    const { rows: [cur] } = await query('SELECT * FROM current_screening WHERE security_id = $1', [id]);
    const { rows: [row] } = await query(
      `INSERT INTO screenings (security_id, status, reason, debt_ratio, deposit_ratio, impure_ratio, market_cap, fiscal_year, manual, reviewed_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,TRUE,$9) RETURNING *`,
      [id, b.status, b.reason, cur?.debt_ratio ?? null, cur?.deposit_ratio ?? null, cur?.impure_ratio ?? null,
        cur?.market_cap ?? null, cur?.fiscal_year ?? null, req.user.id]);
    screening = row;
  }
  await audit({ query }, req.user.id, 'REVUE_CHARIA', { security: id, mode: b.mode, status: screening.status }, req.ip);
  res.json({ screening });
}));

/* ---------- Imports CSV ---------- */

const csvBody = z.object({ csv: z.string().min(1).max(5_000_000) });

async function tickerMap() {
  const { rows } = await query('SELECT id, ticker FROM securities');
  return new Map(rows.map((r) => [r.ticker, r.id]));
}

// Colonnes : ticker,date,close
router.post('/import/prices', ADMIN, wrap(async (req, res) => {
  const rows = parseCsv(csvBody.parse(req.body).csv);
  const map = await tickerMap();
  const errors = [];
  const valid = [];
  for (const r of rows) {
    const id = map.get(String(r.ticker || '').toUpperCase());
    const close = toInt(r.close);
    if (!id) errors.push(`Ligne ${r._line} : code « ${r.ticker} » inconnu.`);
    else if (!/^\d{4}-\d{2}-\d{2}$/.test(r.date) || Number.isNaN(Date.parse(r.date))) errors.push(`Ligne ${r._line} : date invalide (AAAA-MM-JJ attendu).`);
    else if (!close) errors.push(`Ligne ${r._line} : cours invalide.`);
    else valid.push([id, r.date, close]);
  }
  await tx(async (db) => {
    for (const [id, date, close] of valid) {
      await db.query(
        'INSERT INTO prices (security_id, date, close) VALUES ($1,$2,$3) ON CONFLICT (security_id, date) DO UPDATE SET close = EXCLUDED.close',
        [id, date, close]);
    }
    await rescreenAll(db, await getSettings(db));
    await audit(db, req.user.id, 'IMPORT_COURS', { imported: valid.length, errors: errors.length }, req.ip);
  });
  res.json({ imported: valid.length, errors: errors.slice(0, 50) });
}));

// Colonnes : ticker,fiscal_year,interest_debt,interest_deposits,total_revenue,impure_income
router.post('/import/financials', SHARIA, wrap(async (req, res) => {
  const rows = parseCsv(csvBody.parse(req.body).csv);
  const map = await tickerMap();
  const errors = [];
  const valid = [];
  for (const r of rows) {
    const id = map.get(String(r.ticker || '').toUpperCase());
    const year = toInt(r.fiscal_year);
    const nums = ['interest_debt', 'interest_deposits', 'total_revenue', 'impure_income'].map((k) => toInt(r[k]));
    if (!id) errors.push(`Ligne ${r._line} : code « ${r.ticker} » inconnu.`);
    else if (!year || year < 2000 || year > 2100) errors.push(`Ligne ${r._line} : exercice invalide.`);
    else if (nums.some((n) => n === null)) errors.push(`Ligne ${r._line} : montant manquant ou invalide (entiers en FCFA).`);
    else valid.push([id, year, ...nums]);
  }
  await tx(async (db) => {
    const settings = await getSettings(db);
    for (const v of valid) {
      await db.query(
        `INSERT INTO financials (security_id, fiscal_year, interest_debt, interest_deposits, total_revenue, impure_income)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (security_id, fiscal_year) DO UPDATE SET interest_debt=EXCLUDED.interest_debt,
           interest_deposits=EXCLUDED.interest_deposits, total_revenue=EXCLUDED.total_revenue,
           impure_income=EXCLUDED.impure_income, created_at=now()`, v);
    }
    for (const id of new Set(valid.map((v) => v[0]))) await rescreenSecurity(db, id, settings, { reviewedBy: req.user.id });
    await audit(db, req.user.id, 'IMPORT_FINANCIERS', { imported: valid.length, errors: errors.length }, req.ip);
  });
  res.json({ imported: valid.length, errors: errors.slice(0, 50) });
}));

/* ---------- Dividendes ---------- */

router.get('/dividends', BACK_OFFICE, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT d.*, s.ticker, (SELECT COUNT(*)::int FROM purifications p WHERE p.dividend_id = d.id) AS holders
       FROM dividends d JOIN securities s ON s.id = d.security_id ORDER BY d.id DESC LIMIT 100`);
  res.json({ dividends: rows });
}));

// Saisie d'un dividende net par action : crédite les détenteurs et calcule leur purification.
router.post('/dividends', BACK_OFFICE, wrap(async (req, res) => {
  const b = z.object({
    ticker: z.string().trim().toUpperCase(),
    amount_per_share: z.number().int().positive(),
    pay_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  }).parse(req.body);
  const result = await tx(async (db) => {
    const { rows: [sec] } = await db.query('SELECT * FROM securities WHERE ticker = $1', [b.ticker]);
    if (!sec) throw new HttpError(404, 'Titre introuvable.');
    const { rows: [sc] } = await db.query(
      'SELECT impure_ratio FROM screenings WHERE security_id = $1 AND impure_ratio IS NOT NULL ORDER BY id DESC LIMIT 1', [sec.id]);
    const ratio = sc?.impure_ratio ?? 0;
    const { rows: [div] } = await db.query(
      'INSERT INTO dividends (security_id, amount_per_share, pay_date, impure_ratio, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [sec.id, b.amount_per_share, b.pay_date, ratio, req.user.id]);
    const { rows: holders } = await db.query(
      'SELECT user_id, quantity FROM positions WHERE security_id = $1 AND quantity > 0 FOR UPDATE', [sec.id]);
    for (const h of holders) {
      const amount = h.quantity * b.amount_per_share;
      await db.query("INSERT INTO cash_movements (user_id, type, amount, label) VALUES ($1,'DIVIDENDE',$2,$3)",
        [h.user_id, amount, `Dividende ${sec.ticker} (${b.amount_per_share} FCFA x ${h.quantity})`]);
      await db.query(
        'INSERT INTO purifications (user_id, dividend_id, quantity, dividend_amount, amount_due, paid) VALUES ($1,$2,$3,$4,$5,$6)',
        [h.user_id, div.id, h.quantity, amount, Math.round(amount * ratio), Math.round(amount * ratio) === 0]);
    }
    await audit(db, req.user.id, 'DIVIDENDE_SAISI', { ticker: sec.ticker, amount_per_share: b.amount_per_share, holders: holders.length }, req.ip);
    return { dividend: div, holders: holders.length };
  });
  res.status(201).json(result);
}));

/* ---------- File des ordres (SGI) ---------- */

const ORDER_LIST = `
  SELECT o.*, s.ticker, s.name, u.full_name, u.email, u.sgi_account
    FROM orders o JOIN securities s ON s.id = o.security_id JOIN users u ON u.id = o.user_id`;

router.get('/orders', BACK_OFFICE, wrap(async (req, res) => {
  const open = req.query.scope !== 'all';
  const { rows } = await query(
    ORDER_LIST + (open ? " WHERE o.status IN ('RECU','TRANSMIS','PARTIEL')" : '') + ' ORDER BY o.id DESC LIMIT 500');
  res.json({ orders: rows });
}));

router.get('/orders/export.csv', BACK_OFFICE, wrap(async (_req, res) => {
  const { rows } = await query(ORDER_LIST + " WHERE o.status IN ('RECU','TRANSMIS','PARTIEL') ORDER BY o.id");
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = ['id;date;client;compte_sgi;code;sens;type;quantite;reste;cours_limite;validite;etat'];
  for (const o of rows) {
    lines.push([o.id, o.created_at.toISOString(), esc(o.full_name), esc(o.sgi_account), o.ticker, o.side, o.type,
      o.quantity, o.quantity - o.filled_quantity, o.limit_price ?? '', o.valid_until, o.status].join(';'));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="ordres-${todayISO()}.csv"`);
  res.send('﻿' + lines.join('\n'));
}));

router.post('/orders/:id/transmit', BACK_OFFICE, wrap(async (req, res) => {
  const { rows: [o] } = await query(
    "UPDATE orders SET status='TRANSMIS', updated_at=now() WHERE id=$1 AND status='RECU' RETURNING *", [idOf(req)]);
  if (!o) throw new HttpError(409, "Seul un ordre à l'état « Reçu » peut être transmis.");
  await audit({ query }, req.user.id, 'ORDRE_TRANSMIS', { order: o.id }, req.ip);
  res.json({ order: o });
}));

router.post('/orders/:id/reject', BACK_OFFICE, wrap(async (req, res) => {
  const b = z.object({ reason: z.string().trim().min(3, 'Motif requis.').max(300) }).parse(req.body);
  const { rows: [o] } = await query(
    "UPDATE orders SET status='REJETE', reject_reason=$1, updated_at=now() WHERE id=$2 AND status IN ('RECU','TRANSMIS') AND filled_quantity = 0 RETURNING *",
    [b.reason, idOf(req)]);
  if (!o) throw new HttpError(409, 'Cet ordre ne peut pas être rejeté (déjà exécuté en partie ou clos).');
  await audit({ query }, req.user.id, 'ORDRE_REJETE', { order: o.id, reason: b.reason }, req.ip);
  res.json({ order: o });
}));

/**
 * Enregistre une exécution : espèces, frais, position et état de l'ordre, dans une seule transaction.
 * Exportée pour être appelée par un futur connecteur SGI.
 */
export async function applyExecution(db, orderId, quantity, price, actorId, ip) {
  const { rows: [o] } = await db.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [orderId]);
  if (!o) throw new HttpError(404, 'Ordre introuvable.');
  if (!['TRANSMIS', 'PARTIEL'].includes(o.status)) throw new HttpError(409, "L'ordre doit être transmis avant d'être exécuté.");
  const remaining = o.quantity - o.filled_quantity;
  if (quantity > remaining) throw new HttpError(400, `Quantité supérieure au reste à exécuter (${remaining}).`);
  if (o.type === 'LIMITE') {
    if (o.side === 'ACHAT' && price > o.limit_price) throw new HttpError(400, 'Cours supérieur à la limite du client.');
    if (o.side === 'VENTE' && price < o.limit_price) throw new HttpError(400, 'Cours inférieur à la limite du client.');
  }
  await db.query('SELECT id FROM users WHERE id = $1 FOR UPDATE', [o.user_id]);
  const settings = await getSettings(db);
  const { rows: [sec] } = await db.query('SELECT ticker FROM securities WHERE id = $1', [o.security_id]);
  const gross = quantity * price;
  const fee = Math.round(gross * settings.fee_rate);
  const { rows: [pos] } = await db.query(
    'SELECT quantity, avg_cost FROM positions WHERE user_id=$1 AND security_id=$2 FOR UPDATE', [o.user_id, o.security_id]);

  if (o.side === 'ACHAT') {
    const balance = await cashBalance(db, o.user_id);
    if (gross + fee > balance) throw new HttpError(409, `Solde espèces du client insuffisant (${balance} FCFA).`);
    await db.query("INSERT INTO cash_movements (user_id, type, amount, label, ref_order) VALUES ($1,'ACHAT',$2,$3,$4)",
      [o.user_id, -gross, `Achat ${quantity} ${sec.ticker} à ${price}`, o.id]);
    const oldQty = pos?.quantity || 0;
    const newQty = oldQty + quantity;
    // Prix de revient unitaire, frais d'achat inclus.
    const avg = (oldQty * (pos?.avg_cost || 0) + gross + fee) / newQty;
    await db.query(
      `INSERT INTO positions (user_id, security_id, quantity, avg_cost) VALUES ($1,$2,$3,$4)
       ON CONFLICT (user_id, security_id) DO UPDATE SET quantity = EXCLUDED.quantity, avg_cost = EXCLUDED.avg_cost`,
      [o.user_id, o.security_id, newQty, avg.toFixed(2)]);
  } else {
    if (!pos || pos.quantity < quantity) throw new HttpError(409, 'Le client ne détient pas assez de titres.');
    await db.query("INSERT INTO cash_movements (user_id, type, amount, label, ref_order) VALUES ($1,'VENTE',$2,$3,$4)",
      [o.user_id, gross, `Vente ${quantity} ${sec.ticker} à ${price}`, o.id]);
    const left = pos.quantity - quantity;
    await db.query('UPDATE positions SET quantity=$1, avg_cost=$2 WHERE user_id=$3 AND security_id=$4',
      [left, left === 0 ? 0 : pos.avg_cost, o.user_id, o.security_id]);
  }
  if (fee > 0) {
    await db.query("INSERT INTO cash_movements (user_id, type, amount, label, ref_order) VALUES ($1,'FRAIS',$2,$3,$4)",
      [o.user_id, -fee, `Frais ordre n° ${o.id}`, o.id]);
  }
  const settlement = addBusinessDays(todayISO(), 2); // règlement-livraison en T+2
  await db.query('INSERT INTO executions (order_id, quantity, price, fee, settlement_date, executed_by) VALUES ($1,$2,$3,$4,$5,$6)',
    [o.id, quantity, price, fee, settlement, actorId]);
  const filled = o.filled_quantity + quantity;
  const { rows: [updated] } = await db.query(
    'UPDATE orders SET filled_quantity=$1, status=$2, updated_at=now() WHERE id=$3 RETURNING *',
    [filled, filled === o.quantity ? 'EXECUTE' : 'PARTIEL', o.id]);
  await audit(db, actorId, 'ORDRE_EXECUTE', { order: o.id, quantity, price, fee }, ip);
  return updated;
}

router.post('/orders/:id/execute', BACK_OFFICE, wrap(async (req, res) => {
  const b = z.object({ quantity: z.number().int().positive(), price: z.number().int().positive() }).parse(req.body);
  const id = idOf(req);
  const order = await tx((db) => applyExecution(db, id, b.quantity, b.price, req.user.id, req.ip));
  res.json({ order });
}));

/* ---------- Paramètres et audit ---------- */

router.get('/settings', wrap(async (_req, res) => res.json({ settings: await getSettings({ query }) })));

router.put('/settings', ADMIN, wrap(async (req, res) => {
  const ratio = z.number().min(0).max(1);
  const b = z.object({
    debt_threshold: ratio, deposit_threshold: ratio, impure_threshold: ratio,
    fee_rate: z.number().min(0).max(0.1), max_variation: z.number().min(0.01).max(0.5),
    nisab_fcfa: z.number().int().min(0), zakat_rate: z.number().min(0).max(0.1),
  }).partial().parse(req.body);
  await tx(async (db) => {
    for (const [k, v] of Object.entries(b)) {
      if (!(k in DEFAULT_SETTINGS)) continue;
      await db.query('INSERT INTO settings (key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [k, String(v)]);
    }
    await rescreenAll(db, await getSettings(db));
    await audit(db, req.user.id, 'PARAMETRES_MODIFIES', b, req.ip);
  });
  res.json({ settings: await getSettings({ query }) });
}));

router.get('/audit', ADMIN, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT a.id, a.action, a.detail, a.ip, a.created_at, u.email
       FROM audit_log a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 300`);
  res.json({ entries: rows });
}));

export default router;
