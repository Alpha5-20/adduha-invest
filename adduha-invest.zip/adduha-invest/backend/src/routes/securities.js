import { Router } from 'express';
import { query } from '../db.js';
import { HttpError, wrap, getSettings } from '../util.js';
import { requireAuth } from '../auth.js';

const router = Router();
router.use(requireAuth);

// Liste du marché avec dernier cours, variation et statut charia.
router.get('/securities', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT s.id, s.ticker, s.name, s.sector, s.country,
            lp.close AS last_close, lp.date AS price_date,
            (SELECT close FROM prices p WHERE p.security_id = s.id AND p.date < lp.date ORDER BY p.date DESC LIMIT 1) AS prev_close,
            COALESCE(cs.status, 'A_REVOIR') AS sharia_status
       FROM securities s
       LEFT JOIN last_price lp ON lp.security_id = s.id
       LEFT JOIN current_screening cs ON cs.security_id = s.id
      WHERE s.active
      ORDER BY s.ticker`);
  res.json({ securities: rows });
}));

router.get('/securities/:ticker', wrap(async (req, res) => {
  const ticker = String(req.params.ticker).toUpperCase();
  const { rows: [security] } = await query(
    `SELECT s.*, lp.close AS last_close, lp.date AS price_date
       FROM securities s LEFT JOIN last_price lp ON lp.security_id = s.id WHERE s.ticker = $1`, [ticker]);
  if (!security) throw new HttpError(404, 'Titre introuvable.');
  const [screening, history, prices, dividends, settings] = await Promise.all([
    query('SELECT * FROM current_screening WHERE security_id = $1', [security.id]),
    query(`SELECT sc.id, sc.status, sc.reason, sc.manual, sc.fiscal_year, sc.created_at, u.full_name AS reviewer
             FROM screenings sc LEFT JOIN users u ON u.id = sc.reviewed_by
            WHERE sc.security_id = $1 ORDER BY sc.id DESC LIMIT 20`, [security.id]),
    query(`SELECT date, close FROM (SELECT date, close FROM prices WHERE security_id = $1 ORDER BY date DESC LIMIT 250) t ORDER BY date`, [security.id]),
    query('SELECT amount_per_share, pay_date, impure_ratio FROM dividends WHERE security_id = $1 ORDER BY pay_date DESC LIMIT 10', [security.id]),
    getSettings({ query }),
  ]);
  res.json({
    security,
    screening: screening.rows[0] || { status: 'A_REVOIR', reason: 'Titre pas encore examiné.' },
    screening_history: history.rows,
    prices: prices.rows,
    dividends: dividends.rows,
    thresholds: { debt: settings.debt_threshold, deposit: settings.deposit_threshold, impure: settings.impure_threshold },
    trading: { fee_rate: settings.fee_rate, max_variation: settings.max_variation },
  });
}));

export default router;
