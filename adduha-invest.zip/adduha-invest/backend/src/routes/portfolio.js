import { Router } from 'express';
import { query } from '../db.js';
import { HttpError, wrap, getSettings } from '../util.js';
import { requireAuth } from '../auth.js';
import { getPortfolio } from '../portfolio.js';

const router = Router();
router.use(requireAuth);

router.get('/portfolio', wrap(async (req, res) => {
  const settings = await getSettings({ query });
  res.json(await getPortfolio({ query }, req.user.id, settings));
}));

router.get('/portfolio/movements', wrap(async (req, res) => {
  const { rows } = await query(
    'SELECT id, type, amount, label, ref_order, created_at FROM cash_movements WHERE user_id = $1 ORDER BY id DESC LIMIT 300',
    [req.user.id]);
  res.json({ movements: rows });
}));

// Dividendes reçus et part à purifier.
router.get('/purification', wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT pu.id, s.ticker, s.name, d.pay_date, d.amount_per_share, d.impure_ratio,
            pu.quantity, pu.dividend_amount, pu.amount_due, pu.paid, pu.paid_at
       FROM purifications pu
       JOIN dividends d ON d.id = pu.dividend_id
       JOIN securities s ON s.id = d.security_id
      WHERE pu.user_id = $1 ORDER BY d.pay_date DESC, pu.id DESC`, [req.user.id]);
  const due = rows.filter((r) => !r.paid).reduce((a, r) => a + r.amount_due, 0);
  const paid = rows.filter((r) => r.paid).reduce((a, r) => a + r.amount_due, 0);
  res.json({ items: rows, total_due: due, total_paid: paid });
}));

router.post('/purification/:id/pay', wrap(async (req, res) => {
  const { rowCount } = await query(
    'UPDATE purifications SET paid = TRUE, paid_at = now() WHERE id = $1 AND user_id = $2 AND NOT paid',
    [parseInt(req.params.id, 10), req.user.id]);
  if (!rowCount) throw new HttpError(404, 'Ligne introuvable ou déjà marquée comme versée.');
  res.json({ ok: true });
}));

// Estimation de la zakat : taux x (valeur de marché + espèces), si le nissab est atteint.
router.get('/zakat', wrap(async (req, res) => {
  const settings = await getSettings({ query });
  const p = await getPortfolio({ query }, req.user.id, settings);
  const base = Math.max(0, p.total);
  const nisabSet = settings.nisab_fcfa > 0;
  const liable = nisabSet ? base >= settings.nisab_fcfa : base > 0;
  res.json({
    market_value: p.market_value, cash: p.cash, base,
    nisab: settings.nisab_fcfa, nisab_set: nisabSet, rate: settings.zakat_rate,
    liable, amount: liable ? Math.round(base * settings.zakat_rate) : 0,
  });
}));

export default router;
