import { Router } from 'express';
import { z } from 'zod';
import { query, tx } from '../db.js';
import { HttpError, wrap, getSettings, audit, todayISO } from '../util.js';
import { requireAuth } from '../auth.js';
import { cashBalance, reservedCash, reservedShares, OPEN_STATUSES } from '../portfolio.js';
import { sgi } from '../sgi.js';

const router = Router();
router.use(requireAuth);

const MAX_VALIDITY_DAYS = 30;

const orderSchema = z.object({
  ticker: z.string().trim().toUpperCase(),
  side: z.enum(['ACHAT', 'VENTE']),
  type: z.enum(['MARCHE', 'LIMITE']),
  quantity: z.number().int().positive('La quantité doit être un entier positif.').max(10_000_000),
  limit_price: z.number().int().positive().optional(),
  valid_until: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

router.get('/orders', wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT o.*, s.ticker, s.name,
            (SELECT COALESCE(SUM(e.quantity::bigint * e.price),0)::bigint FROM executions e WHERE e.order_id = o.id) AS executed_amount,
            (SELECT MAX(e.settlement_date) FROM executions e WHERE e.order_id = o.id) AS settlement_date
       FROM orders o JOIN securities s ON s.id = o.security_id
      WHERE o.user_id = $1 ORDER BY o.id DESC LIMIT 200`, [req.user.id]);
  res.json({ orders: rows });
}));

router.post('/orders', wrap(async (req, res) => {
  const b = orderSchema.parse(req.body);
  if (b.type === 'LIMITE' && !b.limit_price) throw new HttpError(400, 'Indiquez un cours limite.');

  const order = await tx(async (db) => {
    // Verrou sur le compte : deux ordres simultanés ne peuvent pas utiliser le même solde.
    const { rows: [user] } = await db.query('SELECT * FROM users WHERE id = $1 FOR UPDATE', [req.user.id]);
    if (user.kyc_status !== 'VALIDE') {
      throw new HttpError(403, "Votre dossier d'identité doit être validé avant de passer un ordre.");
    }
    const settings = await getSettings(db);
    const { rows: [sec] } = await db.query(
      `SELECT s.*, lp.close AS last_close, COALESCE(cs.status,'A_REVOIR') AS sharia_status
         FROM securities s
         LEFT JOIN last_price lp ON lp.security_id = s.id
         LEFT JOIN current_screening cs ON cs.security_id = s.id
        WHERE s.ticker = $1 AND s.active`, [b.ticker]);
    if (!sec) throw new HttpError(404, 'Titre introuvable.');
    if (!sec.last_close) throw new HttpError(409, "Aucun cours connu pour ce titre : ordre impossible pour l'instant.");

    if (b.side === 'ACHAT' && sec.sharia_status !== 'CONFORME') {
      throw new HttpError(403, sec.sharia_status === 'NON_CONFORME'
        ? "Ce titre n'est pas conforme à la charia : l'achat est bloqué."
        : "Ce titre est en cours de revue charia : l'achat est suspendu.");
    }

    const today = todayISO();
    const validUntil = b.valid_until || today;
    const maxDate = new Date(Date.now() + MAX_VALIDITY_DAYS * 86400000).toISOString().slice(0, 10);
    if (validUntil < today || validUntil > maxDate) {
      throw new HttpError(400, `La validité doit être comprise entre aujourd'hui et ${MAX_VALIDITY_DAYS} jours.`);
    }

    const low = Math.floor(sec.last_close * (1 - settings.max_variation));
    const high = Math.ceil(sec.last_close * (1 + settings.max_variation));
    if (b.type === 'LIMITE' && (b.limit_price < low || b.limit_price > high)) {
      throw new HttpError(400, `Le cours limite doit rester entre ${low} et ${high} FCFA (variation maximale par séance).`);
    }

    // Cours servant au blocage : la limite, ou le plus haut possible de la séance pour un ordre au marché.
    let refPrice = sec.last_close;
    if (b.side === 'ACHAT') {
      refPrice = b.type === 'LIMITE' ? b.limit_price : high;
      const needed = Math.ceil(b.quantity * refPrice * (1 + settings.fee_rate));
      const available = (await cashBalance(db, user.id)) - (await reservedCash(db, user.id, settings.fee_rate));
      if (needed > available) {
        throw new HttpError(409, `Espèces disponibles insuffisantes : il faut ${needed} FCFA (frais compris), vous disposez de ${available} FCFA.`);
      }
    } else {
      const { rows: [pos] } = await db.query('SELECT quantity FROM positions WHERE user_id=$1 AND security_id=$2', [user.id, sec.id]);
      const free = (pos?.quantity || 0) - (await reservedShares(db, user.id, sec.id));
      if (b.quantity > free) {
        throw new HttpError(409, `Titres disponibles insuffisants : vous pouvez vendre ${free} action(s) ${sec.ticker}.`);
      }
    }

    const { rows: [created] } = await db.query(
      `INSERT INTO orders (user_id, security_id, side, type, quantity, limit_price, ref_price, valid_until)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [user.id, sec.id, b.side, b.type, b.quantity, b.type === 'LIMITE' ? b.limit_price : null, refPrice, validUntil]);
    await audit(db, user.id, 'ORDRE_RECU', { order: created.id, ticker: sec.ticker, side: b.side, quantity: b.quantity }, req.ip);
    return { ...created, ticker: sec.ticker, name: sec.name };
  });

  await sgi.submitOrder(order);
  res.status(201).json({ order });
}));

router.post('/orders/:id/cancel', wrap(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const order = await tx(async (db) => {
    const { rows: [o] } = await db.query('SELECT * FROM orders WHERE id = $1 AND user_id = $2 FOR UPDATE', [id, req.user.id]);
    if (!o) throw new HttpError(404, 'Ordre introuvable.');
    if (!OPEN_STATUSES.includes(o.status)) throw new HttpError(409, 'Cet ordre ne peut plus être annulé.');
    const { rows: [updated] } = await db.query(
      "UPDATE orders SET status='ANNULE', updated_at=now() WHERE id=$1 RETURNING *", [id]);
    await audit(db, req.user.id, 'ORDRE_ANNULE', { order: id, was: o.status }, req.ip);
    return updated;
  });
  await sgi.cancelOrder(order);
  res.json({ order });
}));

export default router;
