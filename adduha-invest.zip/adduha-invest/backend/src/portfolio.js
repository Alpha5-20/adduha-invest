// Calculs de portefeuille partagés entre les routes client et la prise d'ordres.

export const OPEN_STATUSES = ['RECU', 'TRANSMIS', 'PARTIEL'];

export async function cashBalance(db, userId) {
  const { rows: [r] } = await db.query('SELECT COALESCE(SUM(amount),0)::bigint AS balance FROM cash_movements WHERE user_id = $1', [userId]);
  return r.balance;
}

// Espèces bloquées par les ordres d'achat ouverts, frais compris.
export async function reservedCash(db, userId, feeRate) {
  const { rows: [r] } = await db.query(
    `SELECT COALESCE(SUM((quantity - filled_quantity)::bigint * ref_price),0)::bigint AS gross
       FROM orders WHERE user_id = $1 AND side = 'ACHAT' AND status = ANY($2)`, [userId, OPEN_STATUSES]);
  return Math.ceil(r.gross * (1 + feeRate));
}

// Titres bloqués par les ordres de vente ouverts.
export async function reservedShares(db, userId, securityId) {
  const { rows: [r] } = await db.query(
    `SELECT COALESCE(SUM(quantity - filled_quantity),0)::int AS qty
       FROM orders WHERE user_id = $1 AND security_id = $2 AND side = 'VENTE' AND status = ANY($3)`,
    [userId, securityId, OPEN_STATUSES]);
  return r.qty;
}

export async function getPortfolio(db, userId, settings) {
  const { rows: positions } = await db.query(
    `SELECT s.ticker, s.name, s.sector, p.security_id, p.quantity, p.avg_cost,
            lp.close AS last_close, lp.date AS price_date, cs.status AS sharia_status
       FROM positions p
       JOIN securities s ON s.id = p.security_id
       LEFT JOIN last_price lp ON lp.security_id = p.security_id
       LEFT JOIN current_screening cs ON cs.security_id = p.security_id
      WHERE p.user_id = $1 AND p.quantity > 0
      ORDER BY s.ticker`, [userId]);

  let marketValue = 0;
  let cost = 0;
  for (const p of positions) {
    p.market_value = p.quantity * (p.last_close || 0);
    p.cost = Math.round(p.quantity * p.avg_cost);
    p.unrealized = p.market_value - p.cost;
    marketValue += p.market_value;
    cost += p.cost;
  }
  const cash = await cashBalance(db, userId);
  const reserved = await reservedCash(db, userId, settings.fee_rate);
  return {
    positions,
    cash, reserved, available: cash - reserved,
    market_value: marketValue, cost, unrealized: marketValue - cost,
    total: marketValue + cash,
  };
}
