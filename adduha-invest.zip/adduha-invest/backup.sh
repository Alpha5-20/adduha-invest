#!/bin/sh
# Sauvegarde de la base dans ./backups, en gardant les 30 dernières.
# À lancer chaque nuit, par exemple avec cron :  0 2 * * * cd /opt/adduha-invest && ./backup.sh
set -eu
mkdir -p backups
docker compose exec -T db pg_dump -U adduha adduha | gzip > "backups/adduha-$(date +%Y%m%d-%H%M).sql.gz"
ls -1t backups/adduha-*.sql.gz | tail -n +31 | xargs -r rm --
# Restauration :  gunzip -c backups/FICHIER.sql.gz | docker compose exec -T db psql -U adduha adduha
