import { createContext, useContext, useEffect, useState } from 'react';
import { NavLink, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { api, getToken, setToken } from './api.js';
import { APP_NAME } from './config.js';
import { Login, Register } from './pages/Auth.jsx';
import Market from './pages/Market.jsx';
import Security from './pages/Security.jsx';
import Portfolio from './pages/Portfolio.jsx';
import Orders from './pages/Orders.jsx';
import Halal from './pages/Halal.jsx';
import Profile from './pages/Profile.jsx';
import Admin from './pages/Admin.jsx';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!getToken()) { setReady(true); return; }
    api('/me').then((d) => setUser(d.user)).catch(() => setToken(null)).finally(() => setReady(true));
  }, []);

  const signIn = (token, u) => { setToken(token); setUser(u); navigate('/'); };
  const signOut = () => { setToken(null); setUser(null); navigate('/connexion'); };

  if (!ready) return <p className="muted center">Chargement…</p>;

  return (
    <AuthContext.Provider value={{ user, setUser, signIn, signOut }}>
      {user ? <Shell /> : (
        <Routes>
          <Route path="/inscription" element={<Register />} />
          <Route path="*" element={<Login />} />
        </Routes>
      )}
    </AuthContext.Provider>
  );
}

function Shell() {
  const { user, signOut } = useAuth();
  const staff = user.role !== 'CLIENT';
  const links = [
    ['/', 'Marché'], ['/portefeuille', 'Portefeuille'], ['/ordres', 'Ordres'],
    ['/purification', 'Purification'], ['/profil', 'Profil'],
  ];
  if (staff) links.push(['/admin', 'Gestion']);
  return (
    <>
      <header className="top">
        <div className="brand">{APP_NAME}<small>Actions conformes à la BRVM</small></div>
        <nav className="nav" aria-label="Navigation principale">
          {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>)}
        </nav>
        <button className="link" onClick={signOut}>Déconnexion</button>
      </header>
      {user.role === 'CLIENT' && user.kyc_status !== 'VALIDE' && (
        <p className="banner">
          {user.kyc_status === 'EN_ATTENTE'
            ? "Votre dossier d'identité est en cours de validation. Vous pourrez passer des ordres dès qu'il sera validé."
            : <>Pour passer des ordres, complétez votre fiche d'identité dans <NavLink to="/profil">Profil</NavLink>.</>}
        </p>
      )}
      <main className="page">
        <Routes>
          <Route path="/" element={<Market />} />
          <Route path="/titre/:ticker" element={<Security />} />
          <Route path="/portefeuille" element={<Portfolio />} />
          <Route path="/ordres" element={<Orders />} />
          <Route path="/purification" element={<Halal />} />
          <Route path="/profil" element={<Profile />} />
          <Route path="/admin" element={staff ? <Admin /> : <Navigate to="/" replace />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <footer className="foot">
        Les ordres sont exécutés par la SGI partenaire. Les statuts charia sont donnés à titre d'information et ne sont pas un conseil en investissement. Investir en actions comporte un risque de perte.
      </footer>
    </>
  );
}
