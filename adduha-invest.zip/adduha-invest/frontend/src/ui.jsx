import { useCallback, useEffect, useState } from 'react';
import { api, SHARIA } from './api.js';

// Charge une ressource et expose { data, error, loading, reload }.
export function useApi(path) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const load = useCallback(() => {
    if (!path) return;
    setState((s) => ({ ...s, loading: true }));
    api(path)
      .then((data) => setState({ data, error: null, loading: false }))
      .catch((e) => setState({ data: null, error: e.message, loading: false }));
  }, [path]);
  useEffect(load, [load]);
  return { ...state, reload: load };
}

export function Loader({ state, children }) {
  if (state.error) return <p className="alert ko">{state.error}</p>;
  if (!state.data) return <p className="muted">Chargement…</p>;
  return children(state.data);
}

export const Badge = ({ status }) => {
  const s = SHARIA[status] || SHARIA.A_REVOIR;
  return <span className={'badge ' + s.cls}>{s.label}</span>;
};

export const Alert = ({ msg }) => (msg ? <p className={'alert ' + (msg.ok ? 'ok' : 'ko')} role="status">{msg.text}</p> : null);

// Exécute une action, affiche le résultat, recharge si besoin.
export function useAction(after) {
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const run = async (fn, success = 'Enregistré.') => {
    setBusy(true); setMsg(null);
    try {
      const r = await fn();
      setMsg({ ok: true, text: typeof success === 'function' ? success(r) : success });
      after?.();
      return r;
    } catch (e) { setMsg({ ok: false, text: e.message }); return null; }
    finally { setBusy(false); }
  };
  return { msg, busy, run, setMsg };
}

// Courbe de cours en SVG, sans dépendance.
export function PriceChart({ prices }) {
  if (!prices || prices.length < 2) return <p className="muted">Pas assez de cours pour tracer une courbe.</p>;
  const W = 600, H = 160, P = 6;
  const values = prices.map((p) => p.close);
  const min = Math.min(...values), max = Math.max(...values);
  const span = max - min || 1;
  const pts = prices.map((p, i) => [P + (i * (W - 2 * P)) / (prices.length - 1), H - P - ((p.close - min) / span) * (H - 2 * P)]);
  const line = pts.map(([x, y], i) => (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1)).join(' ');
  const area = line + ` L ${pts[pts.length - 1][0].toFixed(1)} ${H} L ${pts[0][0].toFixed(1)} ${H} Z`;
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`Cours de ${min} à ${max} FCFA`} preserveAspectRatio="none">
      <path d={area} className="chart-area" />
      <path d={line} className="chart-line" />
    </svg>
  );
}

// Jauge d'un ratio face à son seuil.
export function RatioBar({ label, value, threshold }) {
  const known = value !== null && value !== undefined;
  const over = known && value > threshold;
  const width = known ? Math.min(100, (value / (threshold * 2)) * 100) : 0;
  return (
    <div className="ratio">
      <div className="ratio-head">
        <span>{label}</span>
        <strong className={over ? 'neg' : ''}>{known ? (value * 100).toFixed(1).replace('.', ',') + ' %' : 'n. d.'}</strong>
      </div>
      <div className="ratio-track">
        <div className={'ratio-fill ' + (over ? 'over' : '')} style={{ width: width + '%' }} />
        <div className="ratio-mark" title="Seuil" />
      </div>
      <small className="muted">Seuil : {(threshold * 100).toFixed(0)} %</small>
    </div>
  );
}
