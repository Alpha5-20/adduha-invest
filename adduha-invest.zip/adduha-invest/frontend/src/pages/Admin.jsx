import { useState } from 'react';
import { api, day, dayTime, downloadCsv, fcfa, KYC, num, ORDER_STATUS } from '../api.js';
import { Alert, Badge, Loader, useAction, useApi } from '../ui.jsx';
import { useAuth } from '../App.jsx';

const TABS = [
  ['orders', 'Ordres', ['ADMIN', 'SGI']],
  ['users', 'Clients', ['ADMIN', 'SGI']],
  ['securities', 'Titres et charia', ['ADMIN', 'CHARIA']],
  ['imports', 'Imports', ['ADMIN', 'CHARIA']],
  ['dividends', 'Dividendes', ['ADMIN', 'SGI']],
  ['settings', 'Paramètres', ['ADMIN', 'SGI', 'CHARIA']],
  ['audit', 'Journal', ['ADMIN']],
];
const PANELS = { orders: OrdersPanel, users: UsersPanel, securities: SecuritiesPanel, imports: ImportsPanel, dividends: DividendsPanel, settings: SettingsPanel, audit: AuditPanel };

export default function Admin() {
  const { user } = useAuth();
  const tabs = TABS.filter((t) => t[2].includes(user.role));
  const [tab, setTab] = useState(tabs[0][0]);
  const Panel = PANELS[tab];
  return (
    <>
      <h1>Gestion</h1>
      <div className="chips">{tabs.map(([k, l]) => <button key={k} className={'chip ' + (tab === k ? 'on' : '')} onClick={() => setTab(k)}>{l}</button>)}</div>
      <Panel role={user.role} />
    </>
  );
}

/* ---------- Ordres ---------- */
function OrdersPanel() {
  const [scope, setScope] = useState('open');
  const state = useApi('/admin/orders?scope=' + scope);
  const { msg, busy, run } = useAction(state.reload);
  const [exec, setExec] = useState(null); // { id, quantity, price }

  const post = (o, action, body, okText) => run(() => api(`/admin/orders/${o.id}/${action}`, { method: 'POST', body }), okText);
  const reject = (o) => {
    const reason = window.prompt(`Motif du rejet de l'ordre n° ${o.id} :`);
    if (reason) post(o, 'reject', { reason }, 'Ordre rejeté.');
  };
  const submitExec = (e) => {
    e.preventDefault();
    run(() => api(`/admin/orders/${exec.id}/execute`, { method: 'POST', body: { quantity: parseInt(exec.quantity, 10), price: parseInt(exec.price, 10) } }), 'Exécution enregistrée.')
      .then((r) => r && setExec(null));
  };

  return (
    <section className="card">
      <div className="row">
        <h2>File des ordres</h2>
        <span className="spacer" />
        <select value={scope} onChange={(e) => setScope(e.target.value)} aria-label="Filtre">
          <option value="open">En cours</option><option value="all">Tous</option>
        </select>
        <button className="btn small ghost" onClick={() => run(() => downloadCsv('/admin/orders/export.csv', 'ordres.csv'), 'Export téléchargé.')}>Exporter (CSV)</button>
      </div>
      <Alert msg={msg} />
      {exec && (
        <form className="inline-form" onSubmit={submitExec}>
          <strong>Exécution de l'ordre n° {exec.id}</strong>
          <label>Quantité<input type="number" min="1" max={exec.max} value={exec.quantity} onChange={(e) => setExec({ ...exec, quantity: e.target.value })} required /></label>
          <label>Cours (FCFA)<input type="number" min="1" value={exec.price} onChange={(e) => setExec({ ...exec, price: e.target.value })} required /></label>
          <button className="btn small" disabled={busy}>Enregistrer</button>
          <button type="button" className="btn small ghost" onClick={() => setExec(null)}>Fermer</button>
        </form>
      )}
      <Loader state={state}>{(d) => d.orders.length === 0 ? <p className="muted">Aucun ordre à traiter.</p> : (
        <div className="table-wrap"><table>
          <thead><tr><th>N°</th><th>Reçu le</th><th>Client</th><th>Titre</th><th>Sens</th><th className="r">Exécuté / total</th><th className="r">Limite</th><th>Validité</th><th>État</th><th /></tr></thead>
          <tbody>{d.orders.map((o) => (
            <tr key={o.id}>
              <td>{o.id}</td><td>{dayTime(o.created_at)}</td>
              <td>{o.full_name}<br /><span className="muted small">{o.sgi_account || o.email}</span></td>
              <td><strong>{o.ticker}</strong></td>
              <td className={o.side === 'ACHAT' ? 'pos' : 'neg'}>{o.side === 'ACHAT' ? 'Achat' : 'Vente'}</td>
              <td className="r">{num(o.filled_quantity)} / {num(o.quantity)}</td>
              <td className="r">{o.type === 'LIMITE' ? num(o.limit_price) : 'Marché'}</td>
              <td>{day(o.valid_until)}</td>
              <td><span className={'state s-' + o.status}>{ORDER_STATUS[o.status]}</span></td>
              <td className="actions">
                {o.status === 'RECU' && <button className="btn small" disabled={busy} onClick={() => post(o, 'transmit', undefined, 'Ordre marqué comme transmis.')}>Transmettre</button>}
                {['TRANSMIS', 'PARTIEL'].includes(o.status) && (
                  <button className="btn small" onClick={() => setExec({ id: o.id, max: o.quantity - o.filled_quantity, quantity: o.quantity - o.filled_quantity, price: o.limit_price || o.ref_price })}>Exécuter</button>
                )}
                {['RECU', 'TRANSMIS'].includes(o.status) && o.filled_quantity === 0 && <button className="btn small ghost" disabled={busy} onClick={() => reject(o)}>Rejeter</button>}
              </td>
            </tr>
          ))}</tbody>
        </table></div>
      )}</Loader>
    </section>
  );
}

/* ---------- Clients ---------- */
function UsersPanel({ role }) {
  const state = useApi('/admin/users');
  const { msg, busy, run } = useAction(state.reload);
  const kyc = (u, status) => {
    const body = { status };
    if (status === 'REJETE') { body.reason = window.prompt('Motif du rejet :'); if (!body.reason) return; }
    run(() => api(`/admin/users/${u.id}/kyc`, { method: 'POST', body }), status === 'VALIDE' ? 'Dossier validé.' : 'Dossier rejeté.');
  };
  const cash = (u, type) => {
    const raw = window.prompt(`${type === 'DEPOT' ? 'Dépôt' : 'Retrait'} constaté pour ${u.full_name} (FCFA) :`);
    const amount = parseInt(String(raw || '').replace(/\s/g, ''), 10);
    if (!amount || amount <= 0) return;
    run(() => api(`/admin/users/${u.id}/cash`, { method: 'POST', body: { type, amount } }), 'Mouvement enregistré.');
  };
  const setRole = (u, r) => run(() => api(`/admin/users/${u.id}/role`, { method: 'POST', body: { role: r } }), 'Rôle modifié.');
  return (
    <section className="card">
      <h2>Clients et dossiers</h2>
      <Alert msg={msg} />
      <Loader state={state}>{(d) => (
        <div className="table-wrap"><table>
          <thead><tr><th>Nom</th><th>Pièce</th><th>Compte SGI</th><th>Dossier</th><th className="r">Espèces</th><th>Rôle</th><th /></tr></thead>
          <tbody>{d.users.map((u) => (
            <tr key={u.id}>
              <td>{u.full_name}<br /><span className="muted small">{u.email} · {u.phone || 'sans téléphone'} · {u.country || '–'}</span></td>
              <td>{u.id_type ? `${u.id_type} ${u.id_number}` : '–'}</td>
              <td>{u.sgi_account || '–'}</td>
              <td><span className={'state k-' + u.kyc_status}>{KYC[u.kyc_status]}</span></td>
              <td className="r">{num(u.cash)}</td>
              <td>{role === 'ADMIN'
                ? <select value={u.role} onChange={(e) => setRole(u, e.target.value)} aria-label="Rôle">{['CLIENT', 'SGI', 'CHARIA', 'ADMIN'].map((r) => <option key={r}>{r}</option>)}</select>
                : u.role}</td>
              <td className="actions">
                {u.kyc_status === 'EN_ATTENTE' && <>
                  <button className="btn small" disabled={busy} onClick={() => kyc(u, 'VALIDE')}>Valider</button>
                  <button className="btn small ghost" disabled={busy} onClick={() => kyc(u, 'REJETE')}>Rejeter</button>
                </>}
                {u.kyc_status === 'VALIDE' && u.role === 'CLIENT' && <>
                  <button className="btn small ghost" disabled={busy} onClick={() => cash(u, 'DEPOT')}>Dépôt</button>
                  <button className="btn small ghost" disabled={busy} onClick={() => cash(u, 'RETRAIT')}>Retrait</button>
                </>}
              </td>
            </tr>
          ))}</tbody>
        </table></div>
      )}</Loader>
    </section>
  );
}

/* ---------- Titres et charia ---------- */
const EMPTY = { ticker: '', name: '', sector: '', country: '', shares_outstanding: '', activity: 'A_CLASSER', activity_note: '', active: true };

function SecuritiesPanel() {
  const state = useApi('/admin/securities');
  const { msg, busy, run } = useAction(state.reload);
  const [edit, setEdit] = useState(null);
  const [review, setReview] = useState(null);

  const save = (e) => {
    e.preventDefault();
    const body = { ...edit, shares_outstanding: edit.shares_outstanding ? parseInt(String(edit.shares_outstanding).replace(/\s/g, ''), 10) : null };
    delete body.id;
    run(() => (edit.id ? api('/admin/securities/' + edit.id, { method: 'PUT', body }) : api('/admin/securities', { method: 'POST', body })), 'Titre enregistré.')
      .then((r) => r && setEdit(null));
  };
  const saveReview = (e) => {
    e.preventDefault();
    run(() => api(`/admin/securities/${review.id}/screening`, { method: 'POST', body: { mode: 'MANUEL', status: review.status, reason: review.reason } }), 'Décision enregistrée.')
      .then((r) => r && setReview(null));
  };
  const auto = (s) => run(() => api(`/admin/securities/${s.id}/screening`, { method: 'POST', body: { mode: 'AUTO' } }), 'Retour au calcul automatique.');
  const f = (k) => (e) => setEdit({ ...edit, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  return (
    <section className="card">
      <div className="row"><h2>Titres et conformité</h2><span className="spacer" /><button className="btn small" onClick={() => setEdit({ ...EMPTY })}>Ajouter un titre</button></div>
      <Alert msg={msg} />
      {edit && (
        <form className="inline-form col" onSubmit={save}>
          <strong>{edit.id ? 'Modifier ' + edit.ticker : 'Nouveau titre'}</strong>
          <div className="form-grid">
            {!edit.id && <label>Code<input value={edit.ticker} onChange={f('ticker')} required /></label>}
            <label>Nom<input value={edit.name} onChange={f('name')} required /></label>
            <label>Secteur<input value={edit.sector || ''} onChange={f('sector')} /></label>
            <label>Pays<input value={edit.country || ''} onChange={f('country')} /></label>
            <label>Nombre d'actions en circulation<input value={edit.shares_outstanding || ''} onChange={f('shares_outstanding')} inputMode="numeric" /></label>
            <label>Activité
              <select value={edit.activity} onChange={f('activity')}>
                <option value="A_CLASSER">À classer</option><option value="LICITE">Licite</option><option value="EXCLUE">Exclue</option>
              </select>
            </label>
            <label>Note sur l'activité<input value={edit.activity_note || ''} onChange={f('activity_note')} /></label>
            <label className="check"><input type="checkbox" checked={edit.active} onChange={f('active')} /> Titre affiché dans le marché</label>
          </div>
          <div><button className="btn small" disabled={busy}>Enregistrer</button> <button type="button" className="btn small ghost" onClick={() => setEdit(null)}>Fermer</button></div>
        </form>
      )}
      {review && (
        <form className="inline-form col" onSubmit={saveReview}>
          <strong>Décision du comité charia sur {review.ticker}</strong>
          <label>Statut
            <select value={review.status} onChange={(e) => setReview({ ...review, status: e.target.value })}>
              <option value="CONFORME">Conforme</option><option value="NON_CONFORME">Non conforme</option><option value="A_REVOIR">À revoir</option>
            </select>
          </label>
          <label>Motif<input value={review.reason} onChange={(e) => setReview({ ...review, reason: e.target.value })} required minLength="5" /></label>
          <div><button className="btn small" disabled={busy}>Enregistrer la décision</button> <button type="button" className="btn small ghost" onClick={() => setReview(null)}>Fermer</button></div>
        </form>
      )}
      <Loader state={state}>{(d) => (
        <div className="table-wrap"><table>
          <thead><tr><th>Titre</th><th>Activité</th><th className="r">Actions</th><th className="r">Cours</th><th>Exercice</th><th>Statut</th><th /></tr></thead>
          <tbody>{d.securities.map((s) => (
            <tr key={s.id} className={s.active ? '' : 'off'}>
              <td><strong>{s.ticker}</strong><br /><span className="muted small">{s.name}</span></td>
              <td>{{ LICITE: 'Licite', EXCLUE: 'Exclue', A_CLASSER: 'À classer' }[s.activity]}{s.activity_note && <><br /><span className="muted small">{s.activity_note}</span></>}</td>
              <td className="r">{num(s.shares_outstanding)}</td>
              <td className="r">{num(s.last_close)}</td>
              <td>{s.last_fiscal_year || '–'}</td>
              <td><Badge status={s.sharia_status} />{s.manual && <span className="muted small"> comité</span>}<br /><span className="muted small">{s.reason}</span></td>
              <td className="actions">
                <button className="btn small ghost" onClick={() => { setReview(null); setEdit({ ...s }); }}>Modifier</button>
                <button className="btn small ghost" onClick={() => { setEdit(null); setReview({ id: s.id, ticker: s.ticker, status: s.sharia_status || 'A_REVOIR', reason: '' }); }}>Décision</button>
                {s.manual && <button className="btn small ghost" disabled={busy} onClick={() => auto(s)}>Recalculer</button>}
              </td>
            </tr>
          ))}</tbody>
        </table></div>
      )}</Loader>
    </section>
  );
}

/* ---------- Imports ---------- */
function ImportBox({ title, path, columns, example }) {
  const [result, setResult] = useState(null);
  const { msg, busy, run } = useAction();
  const onFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const csv = await file.text();
    e.target.value = '';
    const r = await run(() => api(path, { method: 'POST', body: { csv } }), (x) => `${x.imported} ligne(s) importée(s).`);
    setResult(r);
  };
  return (
    <section className="card">
      <h2>{title}</h2>
      <p className="muted">Fichier CSV, séparateur virgule ou point-virgule. Colonnes : <code>{columns}</code></p>
      <pre>{example}</pre>
      <input type="file" accept=".csv,text/csv,text/plain" onChange={onFile} disabled={busy} />
      <Alert msg={msg} />
      {result?.errors?.length > 0 && <ul className="plain neg">{result.errors.map((x, i) => <li key={i}>{x}</li>)}</ul>}
    </section>
  );
}

function ImportsPanel({ role }) {
  return (
    <>
      {role === 'ADMIN' && <ImportBox title="Cours de clôture" path="/admin/import/prices" columns="ticker,date,close" example={'ticker,date,close\nSNTS,2026-11-10,25000'} />}
      <ImportBox title="Données financières" path="/admin/import/financials"
        columns="ticker,fiscal_year,interest_debt,interest_deposits,total_revenue,impure_income"
        example={'ticker,fiscal_year,interest_debt,interest_deposits,total_revenue,impure_income\nSNTS,2025,400000000000,150000000000,1600000000000,16000000000'} />
      <p className="muted small">Montants en FCFA entiers. Chaque import relance le calcul des statuts, sauf pour les titres sous décision du comité.</p>
    </>
  );
}

/* ---------- Dividendes ---------- */
function DividendsPanel() {
  const state = useApi('/admin/dividends');
  const { msg, busy, run } = useAction(state.reload);
  const [f, setF] = useState({ ticker: '', amount_per_share: '', pay_date: new Date().toISOString().slice(0, 10) });
  const submit = (e) => {
    e.preventDefault();
    if (!window.confirm(`Créditer ${f.amount_per_share} FCFA par action ${f.ticker.toUpperCase()} à tous les détenteurs ? Cette saisie ne s'annule pas.`)) return;
    run(() => api('/admin/dividends', { method: 'POST', body: { ...f, amount_per_share: parseInt(f.amount_per_share, 10) } }),
      (r) => `Dividende enregistré, ${r.holders} détenteur(s) crédité(s).`);
  };
  return (
    <section className="card">
      <h2>Saisir un dividende</h2>
      <form className="inline-form" onSubmit={submit}>
        <label>Code du titre<input value={f.ticker} onChange={(e) => setF({ ...f, ticker: e.target.value })} required /></label>
        <label>Net par action (FCFA)<input type="number" min="1" value={f.amount_per_share} onChange={(e) => setF({ ...f, amount_per_share: e.target.value })} required /></label>
        <label>Date de paiement<input type="date" value={f.pay_date} onChange={(e) => setF({ ...f, pay_date: e.target.value })} required /></label>
        <button className="btn small" disabled={busy}>Enregistrer</button>
      </form>
      <Alert msg={msg} />
      <Loader state={state}>{(d) => d.dividends.length === 0 ? <p className="muted">Aucun dividende saisi.</p> : (
        <div className="table-wrap"><table>
          <thead><tr><th>Titre</th><th>Paiement</th><th className="r">Net par action</th><th className="r">Part illicite</th><th className="r">Détenteurs</th></tr></thead>
          <tbody>{d.dividends.map((v) => (
            <tr key={v.id}><td><strong>{v.ticker}</strong></td><td>{day(v.pay_date)}</td><td className="r">{fcfa(v.amount_per_share)}</td>
              <td className="r">{(v.impure_ratio * 100).toFixed(2).replace('.', ',')} %</td><td className="r">{v.holders}</td></tr>
          ))}</tbody>
        </table></div>
      )}</Loader>
    </section>
  );
}

/* ---------- Paramètres ---------- */
const SETTING_FIELDS = [
  ['debt_threshold', 'Seuil dettes à intérêt / capitalisation', true],
  ['deposit_threshold', 'Seuil placements à intérêt / capitalisation', true],
  ['impure_threshold', "Seuil revenus illicites / chiffre d'affaires", true],
  ['fee_rate', 'Frais par exécution', true],
  ['max_variation', 'Variation maximale par séance', true],
  ['zakat_rate', 'Taux de zakat', true],
  ['nisab_fcfa', 'Nissab (FCFA)', false],
];

function SettingsPanel({ role }) {
  const state = useApi('/admin/settings');
  return <Loader state={state}>{(d) => <SettingsForm initial={d.settings} canEdit={role === 'ADMIN'} />}</Loader>;
}

function SettingsForm({ initial, canEdit }) {
  const toView = (s) => Object.fromEntries(SETTING_FIELDS.map(([k, , isPct]) => [k, isPct ? +(s[k] * 100).toFixed(4) : s[k]]));
  const [f, setF] = useState(toView(initial));
  const { msg, busy, run } = useAction();
  const submit = (e) => {
    e.preventDefault();
    const body = Object.fromEntries(SETTING_FIELDS.map(([k, , isPct]) => [k, isPct ? Number(f[k]) / 100 : parseInt(f[k], 10) || 0]));
    run(async () => { const d = await api('/admin/settings', { method: 'PUT', body }); setF(toView(d.settings)); }, 'Paramètres enregistrés. Les statuts ont été recalculés.');
  };
  return (
    <form className="card" onSubmit={submit}>
      <h2>Paramètres</h2>
      <div className="form-grid">
        {SETTING_FIELDS.map(([k, label, isPct]) => (
          <label key={k}>{label}{isPct ? ' (%)' : ''}
            <input type="number" step="any" min="0" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} disabled={!canEdit} required />
          </label>
        ))}
      </div>
      <p className="muted small">Les seuils par défaut sont ceux de la norme AAOIFI n° 21. Les frais et la variation maximale sont à aligner sur la grille et les règles de la SGI partenaire.</p>
      <Alert msg={msg} />
      {canEdit && <button className="btn" disabled={busy}>Enregistrer</button>}
    </form>
  );
}

/* ---------- Journal ---------- */
function AuditPanel() {
  const state = useApi('/admin/audit');
  return (
    <section className="card">
      <h2>Journal d'audit</h2>
      <Loader state={state}>{(d) => (
        <div className="table-wrap"><table>
          <thead><tr><th>Date</th><th>Auteur</th><th>Action</th><th>Détail</th></tr></thead>
          <tbody>{d.entries.map((a) => (
            <tr key={a.id}><td>{dayTime(a.created_at)}</td><td>{a.email || '–'}</td><td>{a.action}</td><td><code className="small">{JSON.stringify(a.detail)}</code></td></tr>
          ))}</tbody>
        </table></div>
      )}</Loader>
    </section>
  );
}
