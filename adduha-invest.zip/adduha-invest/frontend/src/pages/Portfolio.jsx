import { Link } from 'react-router-dom';
import { dayTime, fcfa, num } from '../api.js';
import { Badge, Loader, useApi } from '../ui.jsx';

const TYPES = { DEPOT: 'Dépôt', RETRAIT: 'Retrait', ACHAT: 'Achat', VENTE: 'Vente', FRAIS: 'Frais', DIVIDENDE: 'Dividende' };

export default function Portfolio() {
  const state = useApi('/portfolio');
  const moves = useApi('/portfolio/movements');
  return (
    <>
      <h1>Portefeuille</h1>
      <Loader state={state}>{(p) => (
        <>
          <div className="stats">
            <div><small>Valeur totale</small><strong>{fcfa(p.total)}</strong></div>
            <div><small>Titres</small><strong>{fcfa(p.market_value)}</strong></div>
            <div><small>Espèces disponibles</small><strong>{fcfa(p.available)}</strong>{p.reserved > 0 && <small>{fcfa(p.reserved)} bloqués par vos ordres</small>}</div>
            <div><small>Plus ou moins-value latente</small><strong className={p.unrealized >= 0 ? 'pos' : 'neg'}>{p.unrealized > 0 ? '+' : ''}{fcfa(p.unrealized)}</strong></div>
          </div>
          {p.positions.some((x) => x.sharia_status === 'NON_CONFORME') && (
            <p className="alert wait">Un titre que vous détenez n'est plus conforme. Vous pouvez le vendre ; l'achat est bloqué.</p>
          )}
          <section className="card">
            <h2>Positions</h2>
            {p.positions.length === 0 ? <p className="muted">Vous ne détenez encore aucun titre. <Link to="/">Voir le marché</Link></p> : (
              <div className="table-wrap"><table>
                <thead><tr><th>Titre</th><th className="r">Quantité</th><th className="r hide-sm">Prix de revient</th><th className="r hide-sm">Cours</th><th className="r">Valeur</th><th className="r">+/- value</th><th>Charia</th></tr></thead>
                <tbody>{p.positions.map((x) => (
                  <tr key={x.security_id}>
                    <td><Link to={'/titre/' + x.ticker}><strong>{x.ticker}</strong></Link></td>
                    <td className="r">{num(x.quantity)}</td>
                    <td className="r hide-sm">{num(Math.round(x.avg_cost))}</td>
                    <td className="r hide-sm">{num(x.last_close)}</td>
                    <td className="r">{num(x.market_value)}</td>
                    <td className={'r ' + (x.unrealized >= 0 ? 'pos' : 'neg')}>{x.unrealized > 0 ? '+' : ''}{num(x.unrealized)}</td>
                    <td><Badge status={x.sharia_status} /></td>
                  </tr>
                ))}</tbody>
              </table></div>
            )}
          </section>
        </>
      )}</Loader>
      <section className="card">
        <h2>Mouvements d'espèces</h2>
        <Loader state={moves}>{(d) => d.movements.length === 0
          ? <p className="muted">Aucun mouvement. Les dépôts se font auprès de la SGI partenaire et apparaissent ici une fois constatés.</p>
          : (
            <div className="table-wrap"><table>
              <thead><tr><th>Date</th><th>Type</th><th className="hide-sm">Libellé</th><th className="r">Montant</th></tr></thead>
              <tbody>{d.movements.map((m) => (
                <tr key={m.id}><td>{dayTime(m.created_at)}</td><td>{TYPES[m.type]}</td><td className="hide-sm">{m.label}</td>
                  <td className={'r ' + (m.amount >= 0 ? 'pos' : 'neg')}>{m.amount > 0 ? '+' : ''}{num(m.amount)}</td></tr>
              ))}</tbody>
            </table></div>
          )}</Loader>
      </section>
    </>
  );
}
