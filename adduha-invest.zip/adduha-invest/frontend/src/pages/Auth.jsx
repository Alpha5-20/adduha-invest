import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { APP_NAME } from '../config.js';
import { useAuth } from '../App.jsx';

function AuthForm({ mode }) {
  const { signIn } = useAuth();
  const register = mode === 'register';
  const [form, setForm] = useState({ full_name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const d = await api(register ? '/auth/register' : '/auth/login', { method: 'POST', body: form });
      signIn(d.token, d.user);
    } catch (err) { setError(err.message); setBusy(false); }
  };

  return (
    <div className="auth">
      <h1>{APP_NAME}</h1>
      <p className="muted">Investir à la BRVM dans des actions conformes à la charia.</p>
      <form className="card" onSubmit={submit}>
        <h2>{register ? 'Créer un compte' : 'Connexion'}</h2>
        {register && (
          <label>Nom complet
            <input value={form.full_name} onChange={set('full_name')} required autoComplete="name" />
          </label>
        )}
        <label>E-mail
          <input type="email" value={form.email} onChange={set('email')} required autoComplete="email" />
        </label>
        <label>Mot de passe
          <input type="password" value={form.password} onChange={set('password')} required minLength={register ? 10 : 1}
            autoComplete={register ? 'new-password' : 'current-password'} />
          {register && <small className="muted">10 caractères minimum.</small>}
        </label>
        {error && <p className="alert ko" role="alert">{error}</p>}
        <button className="btn" disabled={busy}>{register ? 'Créer mon compte' : 'Se connecter'}</button>
        <p className="muted small">
          {register ? <>Déjà inscrit ? <Link to="/connexion">Se connecter</Link></> : <>Pas encore de compte ? <Link to="/inscription">S'inscrire</Link></>}
        </p>
      </form>
    </div>
  );
}

export const Login = () => <AuthForm mode="login" />;
export const Register = () => <AuthForm mode="register" />;
