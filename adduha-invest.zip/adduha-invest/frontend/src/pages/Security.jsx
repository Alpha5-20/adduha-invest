import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, day, fcfa, num, pct } from '../api.js';
import { Alert, Badge, Loader, PriceChart, RatioBar, useAction, useApi } from '../ui.jsx';
import { useAuth } from '../App.jsx';

export default function Security() {
  const { ticker } = useParams();
  const state = useApi('/securities/' + ticker);
  return (
    <>
      <p><Link to="/">← Marché</Link></p>
      <Loader state={state}>{(d) => <Detail d={d} />}</Loader>
    </>
  );
}

function Detail({ d }) {
  const { security: s, screening: sc, thresholds: t } = d;
  return (
    <>
      <div className="title-row">
        <div>
          <h1>{s.ticker} <Badge status={sc.status} /></h1>
          <p className="muted">{s.name} · {s.sector} · {s.country}</p>
        </div>
        <div className="quote">
          <strong>{fcfa(s.last_close)}</strong>
          <small className="muted">Cours du {day(s.price_date)}</small>
        </div>
      </div>

      <div className="grid2">
        <section className="card">
          <h2>Cours</h2>
          <PriceChart prices={d.prices} />
        </section>
        <OrderForm security={s} status={sc.status} trading={d.trading} />
      </div>

      <section className="card">
        <h2>Conformité charia</h2>
        <p>{sc.reason}{sc.manual && <em> (décision du comité charia)</em>}</p>
        <div className="grid3">
          <RatioBar label="Dettes à intérêt / capitalisation" value={sc.debt_ratio} threshold={t.debt} />
          <RatioBar label="Placements à intérêt / capitalisation" value={sc.deposit_ratio} threshold={t.deposit} />
          <RatioBar label="Revenus illicites / chiffre d'affaires" value={sc.impure_ratio} threshold={t.impure} />
        </div>
        <p className="muted small">
          Méthode AAOIFI (norme n° 21). {sc.fiscal_year ? `Exercice ${sc.fiscal_year}. ` : ''}
          {sc.market_cap ? `Capitalisation retenue : ${fcfa(sc.market_cap)}. ` : ''}
          {sc.created_at ? `Dernière revue le ${day(sc.created_at)}.` : ''}
        </p>
        {d.screening_history.length > 1 && (
          <details>
            <summary>Historique des revues</summary>
            <ul className="plain">
              {d.screening_history.map((h) => (
                <li key={h.id}>{day(h.created_at)} · <Badge status={h.status} /> {h.reason}{h.manual ? ' (comité)' : ''}</li>
              ))}
            </ul>
          </details>
        )}
      </section>

      {d.dividends.length > 0 && (
        <section className="card">
          <h2>Dividendes</h2>
          <table>
            <thead><tr><th>Paiement</th><th className="r">Net par action</th><th className="r">Part à purifier</th></tr></thead>
            <tbody>{d.dividends.map((v, i) => (
              <tr key={i}><td>{day(v.pay_date)}</td><td className="r">{fcfa(v.amount_per_share)}</td><td className="r">{pct(v.impure_ratio, 2)}</td></tr>
            ))}</tbody>
          </table>
        </section>
      )}
    </>
  );
}

function OrderForm({ security: s, status, trading }) {
  const { user } = useAuth();
  const [side, setSide] = useState('ACHAT');
  const [type, setType] = useState('LIMITE');
  const [quantity, setQuantity] = useState('');
  const [limit, setLimit] = useState(s.last_close || '');
  const [validUntil, setValidUntil] = useState('');
  const [confirm, setConfirm] = useState(false);
  const { msg, busy, run, setMsg } = useAction();

  const qty = parseInt(quantity, 10) || 0;
  const price = type === 'LIMITE' ? parseInt(limit, 10) || 0 : s.last_close || 0;
  const gross = qty * price;
  const fee = Math.round(gross * trading.fee_rate);
  const low = s.last_close ? Math.floor(s.last_close * (1 - trading.max_variation)) : null;
  const high = s.last_close ? Math.ceil(s.last_close * (1 + trading.max_variation)) : null;

  const blocked =
    user.kyc_status !== 'VALIDE' ? "Votre dossier d'identité doit être validé pour passer un ordre."
      : !s.last_close ? 'Aucun cours connu pour ce titre.'
        : side === 'ACHAT' && status === 'NON_CONFORME' ? "Titre non conforme : l'achat est bloqué. Vous pouvez seulement vendre."
          : side === 'ACHAT' && status === 'A_REVOIR' ? "Titre en cours de revue charia : l'achat est suspendu."
            : null;

  const send = () => run(async () => {
    const body = { ticker: s.ticker, side, type, quantity: qty };
    if (type === 'LIMITE') body.limit_price = price;
    if (validUntil) body.valid_until = validUntil;
    const r = await api('/orders', { method: 'POST', body });
    setConfirm(false); setQuantity('');
    return r;
  }, (r) => `Ordre n° ${r.order.id} reçu. Suivez-le dans l'onglet Ordres.`);

  return (
    <section className="card">
      <h2>Passer un ordre</h2>
      <div className="seg" role="tablist">
        <button className={side === 'ACHAT' ? 'on buy' : ''} onClick={() => { setSide('ACHAT'); setConfirm(false); }}>Acheter</button>
        <button className={side === 'VENTE' ? 'on sell' : ''} onClick={() => { setSide('VENTE'); setConfirm(false); }}>Vendre</button>
      </div>
      {blocked ? <p className="alert wait">{blocked}</p> : (
        <form onSubmit={(e) => { e.preventDefault(); setMsg(null); setConfirm(true); }}>
          <label>Quantité
            <input type="number" min="1" step="1" value={quantity} onChange={(e) => { setQuantity(e.target.value); setConfirm(false); }} required />
          </label>
          <label>Type d'ordre
            <select value={type} onChange={(e) => { setType(e.target.value); setConfirm(false); }}>
              <option value="LIMITE">À cours limité</option>
              <option value="MARCHE">Au marché</option>
            </select>
          </label>
          {type === 'LIMITE' && (
            <label>Cours limite (FCFA)
              <input type="number" min={low} max={high} step="1" value={limit} onChange={(e) => { setLimit(e.target.value); setConfirm(false); }} required />
              <small className="muted">Entre {num(low)} et {num(high)} FCFA.</small>
            </label>
          )}
          <label>Valable jusqu'au (facultatif)
            <input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} />
            <small className="muted">Sans date, l'ordre vaut pour la séance du jour.</small>
          </label>
          {qty > 0 && price > 0 && (
            <dl className="recap">
              <dt>Montant estimé</dt><dd>{fcfa(gross)}</dd>
              <dt>Frais estimés ({pct(trading.fee_rate, 2)})</dt><dd>{fcfa(fee)}</dd>
              <dt>{side === 'ACHAT' ? 'Total à payer' : 'Net à recevoir'}</dt>
              <dd><strong>{fcfa(side === 'ACHAT' ? gross + fee : gross - fee)}</strong></dd>
            </dl>
          )}
          {type === 'MARCHE' && side === 'ACHAT' && <p className="muted small">Pour un achat au marché, le montant bloqué est calculé au cours le plus haut possible de la séance.</p>}
          {!confirm
            ? <button className="btn" disabled={!qty}>Vérifier l'ordre</button>
            : (
              <div className="confirm">
                <p>{side === 'ACHAT' ? 'Acheter' : 'Vendre'} <strong>{num(qty)} {s.ticker}</strong> {type === 'LIMITE' ? `à ${num(price)} FCFA ${side === 'ACHAT' ? 'maximum' : 'minimum'}` : 'au marché'} ?</p>
                <button type="button" className={'btn ' + (side === 'ACHAT' ? 'buy' : 'sell')} disabled={busy} onClick={send}>Confirmer l'ordre</button>
                <button type="button" className="btn ghost" onClick={() => setConfirm(false)}>Modifier</button>
              </div>
            )}
        </form>
      )}
      <Alert msg={msg} />
    </section>
  );
}
