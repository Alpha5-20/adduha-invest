import { Link } from 'react-router-dom';
import { api, day, dayTime, num, ORDER_STATUS } from '../api.js';
import { Alert, Loader, useAction, useApi } from '../ui.jsx';

const OPEN = ['RECU', 'TRANSMIS', 'PARTIEL'];

export default function Orders() {
  const state = useApi('/orders');
  const { msg, busy, run } = useAction(state.reload);
  const cancel = (o) => {
    if (!window.confirm(`Annuler l'ordre n° ${o.id} ?`)) return;
    run(() => api(`/orders/${o.id}/cancel`, { method: 'POST' }), 'Ordre annulé.');
  };
  return (
    <>
      <h1>Mes ordres</h1>
      <Alert msg={msg} />
      <Loader state={state}>{(d) => d.orders.length === 0
        ? <p className="muted">Aucun ordre pour l'instant. Choisissez un titre dans le <Link to="/">marché</Link> pour commencer.</p>
        : (
          <div className="table-wrap"><table>
            <thead><tr><th>N°</th><th>Date</th><th>Titre</th><th>Sens</th><th className="r">Quantité</th><th className="r">Limite</th><th>État</th><th /></tr></thead>
            <tbody>{d.orders.map((o) => (
              <tr key={o.id}>
                <td>{o.id}</td>
                <td>{dayTime(o.created_at)}<br /><span className="muted small">valable jusqu'au {day(o.valid_until)}</span></td>
                <td><Link to={'/titre/' + o.ticker}><strong>{o.ticker}</strong></Link></td>
                <td className={o.side === 'ACHAT' ? 'pos' : 'neg'}>{o.side === 'ACHAT' ? 'Achat' : 'Vente'}</td>
                <td className="r">{num(o.filled_quantity)} / {num(o.quantity)}</td>
                <td className="r">{o.type === 'LIMITE' ? num(o.limit_price) : 'Marché'}</td>
                <td>
                  <span className={'state s-' + o.status}>{ORDER_STATUS[o.status]}</span>
                  {o.reject_reason && <><br /><span className="muted small">{o.reject_reason}</span></>}
                  {o.settlement_date && <><br /><span className="muted small">Règlement-livraison le {day(o.settlement_date)}</span></>}
                </td>
                <td>{OPEN.includes(o.status) && <button className="btn small ghost" disabled={busy} onClick={() => cancel(o)}>Annuler</button>}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}</Loader>
    </>
  );
}
