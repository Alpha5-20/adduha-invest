import { api, day, fcfa, num, pct } from '../api.js';
import { Alert, Loader, useAction, useApi } from '../ui.jsx';

export default function Halal() {
  const pur = useApi('/purification');
  const zakat = useApi('/zakat');
  const { msg, busy, run } = useAction(pur.reload);
  return (
    <>
      <h1>Purification et zakat</h1>
      <section className="card">
        <h2>Purification des dividendes</h2>
        <p className="muted">Pour chaque dividende, la part qui vient de revenus illicites de la société est à donner. Marquez une ligne comme versée une fois le don fait.</p>
        <Alert msg={msg} />
        <Loader state={pur}>{(d) => (
          <>
            <div className="stats">
              <div><small>Reste à donner</small><strong>{fcfa(d.total_due)}</strong></div>
              <div><small>Déjà versé</small><strong>{fcfa(d.total_paid)}</strong></div>
            </div>
            {d.items.length === 0 ? <p className="muted">Aucun dividende reçu pour l'instant.</p> : (
              <div className="table-wrap"><table>
                <thead><tr><th>Titre</th><th>Paiement</th><th className="r">Dividende reçu</th><th className="r hide-sm">Part illicite</th><th className="r">À donner</th><th /></tr></thead>
                <tbody>{d.items.map((i) => (
                  <tr key={i.id}>
                    <td><strong>{i.ticker}</strong></td><td>{day(i.pay_date)}</td>
                    <td className="r">{num(i.dividend_amount)}</td><td className="r hide-sm">{pct(i.impure_ratio, 2)}</td>
                    <td className="r">{num(i.amount_due)}</td>
                    <td>{i.paid ? <span className="muted small">{i.amount_due ? 'Versé' : 'Rien à donner'}</span>
                      : <button className="btn small" disabled={busy} onClick={() => run(() => api(`/purification/${i.id}/pay`, { method: 'POST' }), 'Noté.')}>J'ai versé</button>}</td>
                  </tr>
                ))}</tbody>
              </table></div>
            )}
          </>
        )}</Loader>
      </section>
      <section className="card">
        <h2>Estimation de la zakat</h2>
        <Loader state={zakat}>{(z) => (
          <>
            <dl className="recap">
              <dt>Valeur de marché des titres</dt><dd>{fcfa(z.market_value)}</dd>
              <dt>Espèces</dt><dd>{fcfa(z.cash)}</dd>
              <dt>Base de calcul</dt><dd>{fcfa(z.base)}</dd>
              <dt>Nissab</dt><dd>{z.nisab_set ? fcfa(z.nisab) : 'Non renseigné'}</dd>
              <dt>Zakat estimée ({pct(z.rate, 1)})</dt><dd><strong>{fcfa(z.amount)}</strong></dd>
            </dl>
            {z.nisab_set && !z.liable && <p className="muted">Votre base est sous le nissab : rien à verser sur ce compte.</p>}
            <p className="muted small">Estimation sur ce seul compte, à la date du jour, sans tenir compte de vos autres biens ni de la durée de détention. Demandez l'avis d'un savant pour votre situation.</p>
          </>
        )}</Loader>
      </section>
    </>
  );
}
