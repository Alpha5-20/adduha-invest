import { useState } from 'react';
import { api, KYC } from '../api.js';
import { Alert, useAction } from '../ui.jsx';
import { useAuth } from '../App.jsx';

const ID_TYPES = { CNI: "Carte nationale d'identité", PASSEPORT: 'Passeport', CARTE_CONSULAIRE: 'Carte consulaire', NINA: 'Carte NINA' };

export default function Profile() {
  const { user, setUser } = useAuth();
  const [f, setF] = useState({
    full_name: user.full_name || '', phone: user.phone || '', country: user.country || '',
    id_type: user.id_type || 'CNI', id_number: user.id_number || '', sgi_account: user.sgi_account || '',
  });
  const { msg, busy, run } = useAction();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const locked = user.kyc_status === 'VALIDE';

  const submit = (e) => {
    e.preventDefault();
    run(async () => { const d = await api('/me', { method: 'PUT', body: f }); setUser(d.user); }, 'Dossier envoyé. La SGI partenaire va le vérifier.');
  };

  return (
    <>
      <h1>Profil</h1>
      <section className="card">
        <p>Compte : <strong>{user.email}</strong></p>
        <p>Dossier d'identité : <span className={'state k-' + user.kyc_status}>{KYC[user.kyc_status]}</span></p>
        {user.kyc_status === 'REJETE' && <p className="alert ko">Motif du rejet : {user.kyc_reason}. Corrigez puis renvoyez le dossier.</p>}
      </section>
      <form className="card" onSubmit={submit}>
        <h2>Fiche d'identité</h2>
        <div className="form-grid">
          <label>Nom complet<input value={f.full_name} onChange={set('full_name')} required disabled={locked} /></label>
          <label>Téléphone<input value={f.phone} onChange={set('phone')} required disabled={locked} placeholder="+223 …" /></label>
          <label>Pays de résidence<input value={f.country} onChange={set('country')} required disabled={locked} /></label>
          <label>Type de pièce
            <select value={f.id_type} onChange={set('id_type')} disabled={locked}>
              {Object.entries(ID_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </label>
          <label>Numéro de la pièce<input value={f.id_number} onChange={set('id_number')} required disabled={locked} /></label>
          <label>Numéro de compte titres à la SGI (si vous en avez un)<input value={f.sgi_account} onChange={set('sgi_account')} disabled={locked} /></label>
        </div>
        <Alert msg={msg} />
        {locked ? <p className="muted">Dossier validé. Pour modifier une information, contactez le support.</p>
          : <button className="btn" disabled={busy}>Envoyer mon dossier</button>}
      </form>
    </>
  );
}
