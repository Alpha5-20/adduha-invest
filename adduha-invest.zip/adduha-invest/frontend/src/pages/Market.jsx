import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { num, pct } from '../api.js';
import { Badge, Loader, useApi } from '../ui.jsx';

export default function Market() {
  const state = useApi('/securities');
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [sector, setSector] = useState('');

  const all = state.data?.securities || [];
  const sectors = useMemo(() => [...new Set(all.map((s) => s.sector).filter(Boolean))].sort(), [all]);
  const counts = useMemo(() => all.reduce((a, s) => ({ ...a, [s.sharia_status]: (a[s.sharia_status] || 0) + 1 }), {}), [all]);
  const rank = { CONFORME: 0, A_REVOIR: 1, NON_CONFORME: 2 };
  const list = [...all].sort((a, b) => rank[a.sharia_status] - rank[b.sharia_status] || a.ticker.localeCompare(b.ticker)).filter((s) =>
    (!status || s.sharia_status === status) && (!sector || s.sector === sector) &&
    (!q || (s.ticker + ' ' + s.name).toLowerCase().includes(q.toLowerCase())));

  return (
    <>
      <h1>Marché</h1>
      <Loader state={state}>{() => (
        <>
          <div className="chips">
            {[['', 'Tous', all.length], ['CONFORME', 'Conformes', counts.CONFORME || 0], ['NON_CONFORME', 'Non conformes', counts.NON_CONFORME || 0], ['A_REVOIR', 'À revoir', counts.A_REVOIR || 0]].map(([v, l, n]) => (
              <button key={v} className={'chip ' + (status === v ? 'on' : '')} onClick={() => setStatus(v)}>{l} <b>{n}</b></button>
            ))}
          </div>
          <div className="filters">
            <input placeholder="Rechercher un titre" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Rechercher un titre" />
            <select value={sector} onChange={(e) => setSector(e.target.value)} aria-label="Secteur">
              <option value="">Tous les secteurs</option>
              {sectors.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Titre</th><th className="hide-sm">Secteur</th><th className="r">Cours</th><th className="r hide-sm">Variation</th><th>Charia</th></tr></thead>
              <tbody>
                {list.map((s) => {
                  const v = s.last_close && s.prev_close ? s.last_close / s.prev_close - 1 : null;
                  return (
                    <tr key={s.id}>
                      <td><Link to={'/titre/' + s.ticker}><strong>{s.ticker}</strong><br /><span className="muted small">{s.name}</span></Link></td>
                      <td className="hide-sm">{s.sector}</td>
                      <td className="r">{num(s.last_close)}</td>
                      <td className={'r hide-sm ' + (v > 0 ? 'pos' : v < 0 ? 'neg' : '')}>{v === null ? '–' : (v > 0 ? '+' : '') + pct(v, 2)}</td>
                      <td><Badge status={s.sharia_status} /></td>
                    </tr>
                  );
                })}
                {!list.length && <tr><td colSpan="5" className="muted">Aucun titre ne correspond.</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}</Loader>
    </>
  );
}
