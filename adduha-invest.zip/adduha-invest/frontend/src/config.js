// Nom affiché dans l'application : à changer ici (et dans index.html).
export const APP_NAME = 'Ad-Duha Invest';
