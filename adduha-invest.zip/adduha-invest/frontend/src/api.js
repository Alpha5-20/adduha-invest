// Appels à l'API. Le jeton de session est gardé dans le navigateur.
const KEY = 'adduha_token';

export const getToken = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
export const setToken = (t) => { try { t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY); } catch { /* stockage indisponible */ } };

export async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = 'Bearer ' + token;
  let res;
  try {
    res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Connexion impossible. Vérifiez votre réseau.');
  }
  let data = {};
  try { data = await res.json(); } catch { /* réponse sans JSON */ }
  if (res.status === 401 && token) {
    setToken(null);
    window.location.assign('/connexion');
  }
  if (!res.ok) throw new Error(data.error || 'Erreur ' + res.status);
  return data;
}

export async function downloadCsv(path, filename) {
  const res = await fetch('/api' + path, { headers: { Authorization: 'Bearer ' + getToken() } });
  if (!res.ok) throw new Error('Export impossible.');
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  a.click();
  URL.revokeObjectURL(url);
}

const nf = new Intl.NumberFormat('fr-FR');
export const fcfa = (n) => (n === null || n === undefined ? '–' : nf.format(Math.round(n)) + ' FCFA');
export const num = (n) => (n === null || n === undefined ? '–' : nf.format(n));
export const pct = (x, d = 1) => (x === null || x === undefined ? '–' : (x * 100).toFixed(d).replace('.', ',') + ' %');
export const day = (d) => (d ? new Date(d).toLocaleDateString('fr-FR') : '–');
export const dayTime = (d) => (d ? new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '–');

export const SHARIA = {
  CONFORME: { label: 'Conforme', cls: 'ok' },
  NON_CONFORME: { label: 'Non conforme', cls: 'ko' },
  A_REVOIR: { label: 'À revoir', cls: 'wait' },
};
export const ORDER_STATUS = {
  RECU: 'Reçu', TRANSMIS: 'Transmis', PARTIEL: 'Partiel', EXECUTE: 'Exécuté',
  ANNULE: 'Annulé', REJETE: 'Rejeté', EXPIRE: 'Expiré',
};
export const KYC = {
  NON_SOUMIS: 'Non soumis', EN_ATTENTE: 'En attente de validation', VALIDE: 'Validé', REJETE: 'Rejeté',
};
