# Ad-Duha Invest

Application d'investissement halal à la BRVM : filtrage charia des actions, passage d'ordres par une SGI partenaire, suivi de portefeuille, purification des dividendes et estimation de la zakat.

- `frontend/` : interface React (Vite), servie par Caddy
- `backend/` : API Node.js (Express)
- PostgreSQL 16 pour les données

Le cahier des charges décrit le périmètre et les règles métier. Ce fichier explique comment installer et faire tourner l'application.

## Avant d'ouvrir au public

Le code gère le circuit complet d'un ordre, mais il ne parle à aucun système de marché : l'opérateur de la SGI partenaire traite les ordres depuis l'onglet Gestion. N'ouvrez le passage d'ordres à de vrais clients qu'une fois la convention signée avec une SGI autorisée à la bourse en ligne et l'avis juridique obtenu.

Trois vérifications à faire sur les données chargées au premier démarrage :

1. La liste des titres (`backend/src/seed.js`) est à comparer à la cote officielle de la BRVM.
2. Le pré-classement des activités (banques, brasserie, tabac, loterie exclues ; le reste « à classer ») est à valider par le comité charia.
3. Les frais (1 %) et la variation maximale par séance (7,5 %) sont des valeurs par défaut à aligner sur la SGI, dans Gestion > Paramètres.

## Installation sur un serveur

Il faut un serveur Linux (2 Go de mémoire suffisent), Docker avec le module Compose, et un nom de domaine qui pointe vers le serveur. Les ports 80 et 443 doivent être ouverts.

```sh
# 1. Copier le dossier sur le serveur, puis :
cd adduha-invest
cp .env.example .env
nano .env            # remplir DOMAIN, DB_PASSWORD, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD

# 2. Construire et démarrer
docker compose up -d --build

# 3. Vérifier
docker compose ps
docker compose logs -f api
```

L'application répond sur `https://VOTRE-DOMAINE`. Caddy obtient et renouvelle le certificat HTTPS. Les tables et les titres sont créés au premier démarrage, ainsi que le compte administrateur défini dans `.env`.

Mise à jour après une modification du code : `docker compose up -d --build`.

Sauvegarde : `./backup.sh` (voir les commentaires du fichier pour la planifier et pour restaurer).

## Premiers pas

1. Connectez-vous avec le compte administrateur.
2. Gestion > Titres et charia : renseignez le nombre d'actions de chaque société et classez son activité.
3. Gestion > Imports : importez les cours, puis les données financières. Les statuts se calculent tout seuls.
4. Gestion > Clients : donnez le rôle SGI ou CHARIA aux comptes de vos partenaires (ils s'inscrivent d'abord comme tout le monde).
5. Un client s'inscrit, remplit sa fiche dans Profil ; l'opérateur SGI valide le dossier et enregistre son dépôt.

### Formats des fichiers

Cours (`ticker,date,close`) :

```
ticker,date,close
SNTS,2026-11-10,25000
```

Données financières, montants en FCFA entiers :

```
ticker,fiscal_year,interest_debt,interest_deposits,total_revenue,impure_income
SNTS,2025,400000000000,150000000000,1600000000000,16000000000
```

- `interest_debt` : dettes portant intérêt (emprunts bancaires et obligataires)
- `interest_deposits` : dépôts et titres portant intérêt
- `total_revenue` : chiffre d'affaires et autres produits
- `impure_income` : revenus non conformes (surtout les produits financiers d'intérêts)

Le séparateur peut être une virgule ou un point-virgule.

## Rôles

| Rôle | Accès |
| --- | --- |
| CLIENT | Marché, ordres, portefeuille, purification, zakat |
| SGI | Dossiers clients, dépôts et retraits, file des ordres, dividendes |
| CHARIA | Titres, données financières, décisions de conformité |
| ADMIN | Tout, plus les cours, les paramètres, les rôles et le journal d'audit |

## Travailler sur le code

Il faut Node.js 20 ou plus et une base PostgreSQL.

```sh
# API
cd backend
npm install
export DATABASE_URL=postgres://adduha:adduha@localhost:5432/adduha
export ADMIN_EMAIL=admin@test.local ADMIN_PASSWORD=admin-test-2026
npm run dev                  # http://localhost:4000

# Interface (autre terminal)
cd frontend
npm install
npm run dev                  # http://localhost:5173, /api est relayé vers l'API
```

Données d'essai, fictives, à ne jamais charger en production : `npm run seed:demo` (crée `client@demo.local` / `demo-client-2026`).

Tests :

```sh
cd backend
npm test                     # règles de filtrage, T+2, lecture CSV
node scripts/e2e.mjs         # 48 contrôles de bout en bout ; l'API doit tourner avec les données d'essai et le compte admin ci-dessus
```

## Où trouver quoi

| Besoin | Fichier |
| --- | --- |
| Règles de filtrage charia | `backend/src/screening.js` |
| Contrôles à la saisie d'un ordre | `backend/src/routes/orders.js` |
| Exécution, espèces, prix de revient | `applyExecution` dans `backend/src/routes/admin.js` |
| Connexion à la SGI (à écrire au lot 2) | `backend/src/sgi.js` |
| Schéma de la base | `backend/src/schema.sql` |
| Paramètres par défaut | `backend/src/config.js` |
| Nom de l'application | `.env` (APP_NAME), `frontend/src/config.js`, `frontend/index.html` |

## Limites connues de cette version

- Pas de réinitialisation du mot de passe par e-mail ni de double authentification.
- Les pièces d'identité ne sont pas téléversées : l'opérateur SGI vérifie le dossier par ses propres moyens.
- Les jours fériés de la BRVM ne sont pas pris en compte dans la date de règlement-livraison.
- Le portefeuille affiché est une copie tenue par l'application ; le compte à la SGI fait foi. Prévoir un rapprochement quotidien.
- Un dividende saisi par erreur ne s'annule pas depuis l'interface.
